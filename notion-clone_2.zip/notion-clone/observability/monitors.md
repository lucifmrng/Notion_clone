# Datadog monitors as code

These monitor definitions are written for the Datadog Terraform provider,
but you can also create them via the UI. The key idea is that monitors
should be in version control, not clicked into existence.

## High-priority alerts (page on-call)

### Hocuspocus down
```hcl
resource "datadog_monitor" "hocuspocus_down" {
  name    = "Hocuspocus has zero active connections during business hours"
  type    = "metric alert"
  message = <<-EOT
    Hocuspocus is reporting 0 active connections.
    Runbook: docs/runbooks/hocuspocus-down.md
    @pagerduty-oncall
  EOT
  query   = "max(last_5m):max:notion.hocuspocus.active_connections{env:production} < 1"
  monitor_thresholds {
    critical = 1
  }
  # Suppress outside business hours when zero connections is normal.
  # Adjust per your traffic pattern.
  evaluation_delay = 60
}
```

### Postgres pool saturated
```hcl
resource "datadog_monitor" "pg_pool_saturated" {
  name  = "Postgres pool waiting > 5 sustained"
  type  = "metric alert"
  query = "avg(last_10m):max:notion.hocuspocus.pg_pool.waiting{*} > 5"
  message = <<-EOT
    Postgres connection pool has had requests waiting for 10 minutes.
    Runbook: docs/runbooks/postgres-slow.md
    @pagerduty-oncall
  EOT
  monitor_thresholds {
    critical = 5
    warning  = 2
  }
}
```

### Error rate spike
```hcl
resource "datadog_monitor" "error_rate_spike" {
  name  = "Web app error rate > 5% over 5 minutes"
  type  = "metric alert"
  query = <<-EOT
    avg(last_5m):
    ( sum:trace.next.request.errors{service:notion-clone-web}.as_rate()
    / sum:trace.next.request.hits{service:notion-clone-web}.as_rate() ) * 100 > 5
  EOT
  message = "@pagerduty-oncall  See Sentry for triage."
  monitor_thresholds {
    critical = 5
    warning  = 2
  }
}
```

### Auth failures spiking
```hcl
resource "datadog_monitor" "auth_failures" {
  name  = "Hocuspocus auth failure rate > 10/min"
  type  = "metric alert"
  query = <<-EOT
    sum(last_5m):sum:notion.hocuspocus.auth{outcome:invalid_token}.as_rate() > 10
  EOT
  message = "Auth flapping — runbook: docs/runbooks/auth-flapping.md  @pagerduty-oncall"
  monitor_thresholds {
    critical = 10
  }
}
```

## Lower-priority alerts (Slack only)

### Search slow
```hcl
resource "datadog_monitor" "search_slow" {
  name  = "Search p95 > 2s sustained"
  type  = "metric alert"
  query = "avg(last_15m):p95:notion.search.query.duration_ms{*} > 2000"
  message = "Search degraded — runbook: docs/runbooks/search-timing-out.md  @slack-eng"
  monitor_thresholds {
    critical = 2000
  }
}
```

### Materialized view stale
The `mv_daily_page_activity` materialized view should refresh every 15
minutes. If it goes stale, reporting data drifts. Best monitored via a
synthetic check that calls `refresh_reporting_aggregates()` and watches
for a non-stale `last_refresh` timestamp.

## Anti-patterns to avoid

- Don't alert on "service is up." Alert on user-visible symptoms.
- Don't alert on error rate without volume context (1/1 is 100% error).
- Don't page for things you can't act on at 3am.
- Don't alert on a missing data point — set evaluation_delay correctly.
