// MUST be the first import. dd-trace patches modules at require time.
import "./observability/tracer.js";

import http from "node:http";
import { Server } from "@hocuspocus/server";
import { Database } from "@hocuspocus/extension-database";
import { createClient } from "@supabase/supabase-js";
import pg from "pg";
import * as Y from "yjs";
import { parseDocumentName } from "./document-name.js";
import { logger } from "./observability/logger.js";
import { initSentry, Sentry } from "./observability/sentry.js";
import { metrics } from "./observability/metrics.js";

initSentry();

// ---------------------------------------------------------------------------
// Env validation
// ---------------------------------------------------------------------------
const required = [
  "DATABASE_URL",
  "NEXT_PUBLIC_SUPABASE_URL",
  "SUPABASE_SERVICE_ROLE_KEY",
] as const;
for (const name of required) {
  if (!process.env[name]) {
    logger.fatal({ env_var: name }, "missing required env var");
    process.exit(1);
  }
}

const PORT = Number(process.env.PORT) || 1234;
const HEALTH_PORT = Number(process.env.HEALTH_PORT) || 1235;

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { persistSession: false, autoRefreshToken: false } },
);

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX ?? "10"),
  idleTimeoutMillis: 30_000,
});

pool.on("error", (err) => {
  logger.error({ err }, "postgres pool error");
  Sentry.captureException(err);
});

let activeConnections = 0;

function extractPlaintext(ydoc: Y.Doc): string {
  const fragment = ydoc.getXmlFragment("default");
  const out: string[] = [];
  const walk = (node: Y.XmlElement | Y.XmlFragment | Y.XmlText) => {
    if (node instanceof Y.XmlText) {
      out.push(node.toString());
      return;
    }
    if ("toArray" in node) {
      for (const child of node.toArray()) {
        walk(child as Y.XmlElement | Y.XmlText);
      }
    }
  };
  walk(fragment);
  return out.join(" ").replace(/\s+/g, " ").trim();
}

const server = new Server({
  port: PORT,

  async onAuthenticate({ documentName, token }) {
    const log = logger.child({ documentName, op: "onAuthenticate" });
    const start = performance.now();

    const parsed = parseDocumentName(documentName);
    if (!parsed) {
      metrics.increment("notion.hocuspocus.auth", 1, ["outcome:invalid_doc_name"]);
      log.warn("invalid document name");
      throw new Error("invalid document name");
    }
    if (!token) {
      metrics.increment("notion.hocuspocus.auth", 1, ["outcome:missing_token"]);
      log.warn({ workspace_id: parsed.workspaceId }, "missing token");
      throw new Error("missing token");
    }

    const { data: userData, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userData.user) {
      metrics.increment("notion.hocuspocus.auth", 1, ["outcome:invalid_token"]);
      log.warn({ workspace_id: parsed.workspaceId, err: userErr?.message }, "invalid token");
      throw new Error("invalid token");
    }

    const userId = userData.user.id;

    const { data: isMember, error: memErr } = await supabase.rpc(
      "is_workspace_member",
      { p_workspace_id: parsed.workspaceId, p_user_id: userId },
    );
    if (memErr) {
      metrics.increment("notion.hocuspocus.auth", 1, ["outcome:rpc_error"]);
      log.error({ err: memErr.message, user_id: userId }, "membership check failed");
      Sentry.captureException(new Error(`membership check failed: ${memErr.message}`));
      throw new Error("authorization failed");
    }
    if (!isMember) {
      metrics.increment("notion.hocuspocus.auth", 1, ["outcome:not_member"]);
      log.warn(
        { user_id: userId, workspace_id: parsed.workspaceId },
        "not a workspace member",
      );
      throw new Error("not a workspace member");
    }

    const { rows } = await pool.query<{ workspace_id: string }>(
      "select workspace_id from pages where id = $1",
      [parsed.pageId],
    );
    if (rows.length === 0 || rows[0]!.workspace_id !== parsed.workspaceId) {
      metrics.increment("notion.hocuspocus.auth", 1, ["outcome:page_mismatch"]);
      log.warn(
        { user_id: userId, workspace_id: parsed.workspaceId, page_id: parsed.pageId },
        "page/workspace mismatch",
      );
      throw new Error("page/workspace mismatch");
    }

    metrics.increment("notion.hocuspocus.auth", 1, ["outcome:success"]);
    metrics.histogram(
      "notion.hocuspocus.auth.duration_ms",
      performance.now() - start,
      [],
    );
    log.info(
      { user_id: userId, workspace_id: parsed.workspaceId, page_id: parsed.pageId },
      "authenticated",
    );

    return {
      user: { id: userId, email: userData.user.email },
      workspaceId: parsed.workspaceId,
      pageId: parsed.pageId,
    };
  },

  async onConnect({ documentName }) {
    activeConnections++;
    metrics.gauge("notion.hocuspocus.active_connections", activeConnections, []);
    metrics.increment("notion.hocuspocus.connect", 1, []);
    logger.info({ documentName, active_connections: activeConnections }, "client connected");
  },

  async onDisconnect({ documentName }) {
    activeConnections = Math.max(0, activeConnections - 1);
    metrics.gauge("notion.hocuspocus.active_connections", activeConnections, []);
    metrics.increment("notion.hocuspocus.disconnect", 1, []);
    logger.info(
      { documentName, active_connections: activeConnections },
      "client disconnected",
    );
  },

  extensions: [
    new Database({
      async fetch({ documentName }) {
        const parsed = parseDocumentName(documentName);
        if (!parsed) return null;
        const start = performance.now();
        try {
          const { rows } = await pool.query<{ state: Buffer }>(
            "select state from page_yjs_state where page_id = $1",
            [parsed.pageId],
          );
          metrics.histogram(
            "notion.hocuspocus.fetch.duration_ms",
            performance.now() - start,
            ["hit:" + (rows.length > 0 ? "true" : "false")],
          );
          if (rows.length === 0) return null;
          return rows[0]!.state;
        } catch (err) {
          logger.error({ err, page_id: parsed.pageId }, "fetch failed");
          Sentry.captureException(err);
          throw err;
        }
      },

      async store({ documentName, state, document }) {
        const parsed = parseDocumentName(documentName);
        if (!parsed) return;
        const log = logger.child({ page_id: parsed.pageId, op: "store" });
        const start = performance.now();

        const { rows: pageRows } = await pool.query<{
          org_id: string;
          workspace_id: string;
        }>("select org_id, workspace_id from pages where id = $1", [parsed.pageId]);
        if (pageRows.length === 0) {
          log.warn("store skipped: page not found");
          return;
        }
        const { org_id, workspace_id } = pageRows[0]!;

        const plaintext = extractPlaintext(document);

        const client = await pool.connect();
        try {
          await client.query("begin");
          await client.query(
            `insert into page_yjs_state (page_id, org_id, workspace_id, state, updated_at)
             values ($1, $2, $3, $4, now())
             on conflict (page_id) do update set state = excluded.state, updated_at = now()`,
            [parsed.pageId, org_id, workspace_id, state],
          );
          await client.query(
            `update pages set content_text = $1 where id = $2`,
            [plaintext.slice(0, 200_000), parsed.pageId],
          );
          await client.query("commit");

          const duration = performance.now() - start;
          metrics.histogram("notion.hocuspocus.store.duration_ms", duration, [
            "outcome:success",
          ]);
          metrics.histogram("notion.hocuspocus.store.state_bytes", state.byteLength, []);
          log.info(
            { duration_ms: Math.round(duration), state_bytes: state.byteLength },
            "persisted",
          );
        } catch (err) {
          await client.query("rollback");
          metrics.histogram(
            "notion.hocuspocus.store.duration_ms",
            performance.now() - start,
            ["outcome:error"],
          );
          log.error({ err }, "persistence failed");
          Sentry.captureException(err);
          throw err;
        } finally {
          client.release();
        }
      },
    }),
  ],

  async onListen() {
    logger.info({ port: PORT }, "hocuspocus listening");
  },
});

server.listen();

// ---------------------------------------------------------------------------
// Health check server (separate port, separate HTTP server). Hocuspocus owns
// the WS port; a small HTTP server on its own port is the cleanest mix.
// ---------------------------------------------------------------------------
const healthServer = http.createServer(async (req, res) => {
  if (req.method !== "GET" || !req.url) {
    res.writeHead(404).end();
    return;
  }
  const url = new URL(req.url, "http://localhost");

  if (url.pathname === "/health") {
    const deep = url.searchParams.get("deep") === "1";
    if (!deep) {
      res.writeHead(200, {
        "content-type": "application/json",
        "cache-control": "no-store",
      });
      res.end(
        JSON.stringify({
          status: "ok",
          active_connections: activeConnections,
          version: process.env.DD_VERSION ?? "unknown",
        }),
      );
      return;
    }

    try {
      await pool.query("select 1");
      res.writeHead(200, {
        "content-type": "application/json",
        "cache-control": "no-store",
      });
      res.end(
        JSON.stringify({
          status: "ok",
          checks: { postgres: "ok" },
          active_connections: activeConnections,
        }),
      );
    } catch (err) {
      logger.error({ err }, "deep health check failed");
      res.writeHead(503, {
        "content-type": "application/json",
        "cache-control": "no-store",
      });
      res.end(JSON.stringify({ status: "degraded", checks: { postgres: "fail" } }));
    }
    return;
  }

  res.writeHead(404).end();
});
healthServer.listen(HEALTH_PORT, () => {
  logger.info({ port: HEALTH_PORT }, "health server listening");
});

// Periodic pool gauges. dd-trace handles runtime metrics (heap, event-loop)
// for us; this is for app-level state that's expensive to measure on every event.
setInterval(() => {
  metrics.gauge("notion.hocuspocus.pg_pool.total", pool.totalCount, []);
  metrics.gauge("notion.hocuspocus.pg_pool.idle", pool.idleCount, []);
  metrics.gauge("notion.hocuspocus.pg_pool.waiting", pool.waitingCount, []);
}, 10_000).unref();

// Process-wide error handlers. Without these, an unhandled rejection
// silently crashes the process with no diagnostic.
process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "unhandled promise rejection");
  Sentry.captureException(reason);
});
process.on("uncaughtException", (err) => {
  logger.fatal({ err }, "uncaught exception");
  Sentry.captureException(err);
  setTimeout(() => process.exit(1), 1000);
});

const shutdown = async (signal: string) => {
  logger.info({ signal }, "shutting down");
  try {
    healthServer.close();
    await server.destroy();
    await pool.end();
    await Sentry.close(2000);
    process.exit(0);
  } catch (err) {
    logger.error({ err }, "shutdown failed");
    process.exit(1);
  }
};
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
