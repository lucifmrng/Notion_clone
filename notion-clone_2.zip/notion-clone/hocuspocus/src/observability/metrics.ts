interface MetricsClient {
  increment(name: string, value?: number, tags?: string[]): void;
  gauge(name: string, value: number, tags?: string[]): void;
  histogram(name: string, value: number, tags?: string[]): void;
}

const noop: MetricsClient = {
  increment() {},
  gauge() {},
  histogram() {},
};

let cached: MetricsClient | null = null;

function getClient(): MetricsClient {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const tracer = require("dd-trace");
    const dogstatsd = tracer?.dogstatsd;
    if (!dogstatsd) return noop;
    return {
      increment: dogstatsd.increment.bind(dogstatsd),
      gauge: dogstatsd.gauge.bind(dogstatsd),
      histogram: dogstatsd.histogram.bind(dogstatsd),
    };
  } catch {
    return noop;
  }
}

export const metrics: MetricsClient = new Proxy({} as MetricsClient, {
  get(_t, prop: keyof MetricsClient) {
    if (!cached) cached = getClient();
    return cached[prop];
  },
});
