import pino, { type Logger } from "pino";

const isProd = process.env.NODE_ENV === "production";

export const logger: Logger = pino({
  level: process.env.LOG_LEVEL ?? (isProd ? "info" : "debug"),
  redact: {
    paths: [
      "*.password",
      "*.token",
      "*.access_token",
      "*.refresh_token",
      "*.authorization",
      "*.api_key",
      "*.secret",
      "*.SUPABASE_SERVICE_ROLE_KEY",
      "*.DATABASE_URL",
    ],
    censor: "[REDACTED]",
  },
  mixin() {
    try {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const tracer = require("dd-trace");
      const span = tracer?.scope?.()?.active?.();
      if (!span) return {};
      const ctx = span.context();
      return {
        "dd.trace_id": ctx.toTraceId(),
        "dd.span_id": ctx.toSpanId(),
      };
    } catch {
      return {};
    }
  },
  formatters: {
    level(label) {
      return { level: label, status: label };
    },
  },
  base: {
    service: process.env.DD_SERVICE ?? "notion-clone-hocuspocus",
    env: process.env.DD_ENV ?? "development",
    version: process.env.DD_VERSION ?? "0.1.0",
  },
  transport: !isProd
    ? {
        target: "pino-pretty",
        options: {
          colorize: true,
          translateTime: "SYS:HH:MM:ss.l",
          ignore: "pid,hostname,service,env,version",
        },
      }
    : undefined,
});
