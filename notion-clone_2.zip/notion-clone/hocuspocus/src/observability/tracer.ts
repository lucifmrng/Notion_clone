/**
 * Datadog tracer init for the Hocuspocus service.
 *
 * MUST be the first import in src/index.ts. dd-trace patches modules at
 * require time, so anything that loads before this won't be traced.
 *
 * What gets auto-instrumented:
 *   - http: WebSocket upgrades show up as HTTP traces
 *   - pg: every query against Postgres
 *   - undici / fetch: outbound calls (Supabase auth.getUser, etc.)
 */

if (
  process.env.NODE_ENV === "production" ||
  process.env.DD_TRACE_ENABLED === "true"
) {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const tracer = require("dd-trace");
  tracer.init({
    service: process.env.DD_SERVICE ?? "notion-clone-hocuspocus",
    env: process.env.DD_ENV ?? "development",
    version: process.env.DD_VERSION ?? "0.1.0",
    sampleRate: Number(process.env.DD_TRACE_SAMPLE_RATE ?? "0.1"),
    runtimeMetrics: true,
    logInjection: true,
    tags: {
      "service.tier": "realtime",
    },
  });

  tracer.use("pg", {
    service: "notion-clone-hocuspocus-pg",
  });
  tracer.use("http", {
    blocklist: ["/health"],
  });
}

export {};
