/**
 * Document name format passed from the editor to Hocuspocus:
 *   "<workspaceId>:<pageId>"
 * Both must be UUIDs. Returns null on malformed input.
 *
 * Security note: this is the FIRST gate on every WS connection. A bug here
 * that returns a valid object for malformed input would let a client
 * impersonate any document name. Keep it strict.
 */
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function parseDocumentName(
  name: string,
): { workspaceId: string; pageId: string } | null {
  if (typeof name !== "string") return null;
  const parts = name.split(":");
  if (parts.length !== 2) return null;
  const [workspaceId, pageId] = parts;
  if (!workspaceId || !pageId) return null;
  if (!UUID_RE.test(workspaceId) || !UUID_RE.test(pageId)) return null;
  return { workspaceId, pageId };
}
