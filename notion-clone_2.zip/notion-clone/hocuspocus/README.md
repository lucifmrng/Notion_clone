# Hocuspocus Y.js Sync Server

Real-time collaborative editing backend. Validates Supabase JWTs, enforces
workspace membership, and persists Y.Doc state to Postgres.

## Develop

```bash
cp ../.env.example .env
# Fill in: DATABASE_URL, NEXT_PUBLIC_SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
pnpm install
pnpm dev
```

Listens on `:1234` by default. Override with `PORT`.

## Deploy

Any Node host works (Railway, Fly, Render, Cloud Run). Use the Dockerfile.
Environment variables required in production:

- `DATABASE_URL` — direct Postgres connection (not pooler URL; Hocuspocus
  needs persistent connections for transactions). Use Supabase "Session"
  mode connection string.
- `NEXT_PUBLIC_SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` — server-only.
- `PORT` — defaults to 1234.

## Scaling notes

- A single Hocuspocus node handles thousands of concurrent rooms; each room
  is one document. Beyond that, run multiple nodes with sticky sessions or
  use the Redis extension for cross-node awareness.
- The Database extension debounces writes (Hocuspocus default ~2s after last
  edit). Tune via `Database` constructor options if needed.
- Plaintext extraction in `store` is bounded at 200KB. Adjust if you support
  longer documents.
