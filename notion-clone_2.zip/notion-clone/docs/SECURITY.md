# Security

This document is honest about what's hardened, what's hand-wavy, and what
isn't there at all. It is not a substitute for a real security review.

## What this build is hardened against

**Tenant cross-talk via PostgREST.** All tenant-scoped tables have RLS
enabled with policies tested for membership. Helper functions use
`SECURITY DEFINER` to avoid recursion bugs. No table is accessible to
`anon` (except as required by Supabase auth flows).

**Session validation.** Middleware always uses `supabase.auth.getUser()`,
which validates the JWT against Supabase's auth service, not
`getSession()` which only reads the cookie. RSC paths use the same.

**Open-redirect on OAuth callback.** The `next` query param is restricted
to same-origin paths beginning with `/` (and not `//`).

**Hocuspocus connection authorization.** `onAuthenticate` validates the
Supabase JWT and checks workspace membership. The document name parser
is strict (UUID format, single colon separator) and tested. A client
cannot join a document by guessing a string.

**Snippet HTML.** `ts_headline` returns server-generated `<b>` tags
around hits. We render with `dangerouslySetInnerHTML` because the input
is bounded server output. Nothing user-controlled flows into the markup.

**SQL injection.** All Supabase calls go through the typed client; the
direct `pg.Pool` queries in Hocuspocus use parameterized queries
exclusively.

## Known risk areas — accept with care

**Plaintext extraction on save (Hocuspocus).** Capped at 200KB to bound
worst-case payload sizes. Unbounded growth would put pressure on the
search index and on memory at extraction time. Adjust per your scale.

**Service role key in Hocuspocus.** Required to validate JWTs and run
the membership RPC. Treat the Hocuspocus host as a trust boundary equal
to your backend. Rotate the service-role key on personnel changes.

**Materialized view refresh.** `refresh_reporting_aggregates` is
`SECURITY DEFINER` and grantable to `authenticated`. Any logged-in user
can trigger a refresh. For low-traffic deployments this is fine; for
larger ones, rate-limit at the application layer or remove the grant
and run via `pg_cron` exclusively.

**Profile read scope.** Authenticated users can read profiles of users
they share an org with. Email is included in the row. If GDPR/B2B
considerations require email be hidden from non-admin members, drop
`email` from the public read policy or move it to an admin-only view.

## Explicitly out of scope for this build

- **Page-level ACLs.** All pages in a workspace are visible to all
  workspace members. Per-page permissions in a three-tier tenancy is
  its own week of work.
- **Audit log surfacing.** Events are written but there is no UI for
  viewing them as an audit trail. The data is there.
- **MFA enforcement.** Supabase supports MFA; the app does not require it.
- **CSP headers.** Not configured. Set them at the deploy layer
  (Vercel or your CDN) and tighten as needed for the editor.
- **Rate limiting.** Next.js routes are not rate-limited. Use the platform
  layer (Vercel, a WAF, or Supabase's own limits).
- **Invitation email delivery.** The `invites` table exists; the email
  send does not. Wire to your transactional email provider.
- **Password reset / email change flows.** Supabase Auth supports both;
  this app does not surface UI for them.
- **Compliance-scoped logging.** No PII redaction in application logs;
  no log retention policy is encoded.

## Threat model — what this app does *not* claim

- **Side-channel resistance.** RLS prevents data leakage but timing
  attacks against `is_workspace_member` checks are not in scope.
- **Defense against compromised admins.** A workspace owner can do
  anything within their workspace, including extracting data. There is
  no soft-delete protection on pages beyond the `is_archived` flag.
- **Deletion-as-erasure.** Cascading deletes wipe data; there's no
  hold-and-purge workflow for legal holds.

## When to come back to this

Before going to production:

1. Add CSP headers and a security.txt.
2. Wire MFA enforcement for org admins.
3. Encode log retention; redact tokens / PII at the logger.
4. Decide whether to remove the `refresh_reporting_aggregates` grant.
5. Add real rate limiting on `/api/search` and the auth endpoints.
6. Run the schema through `supabase db lint` and an external policy auditor.
