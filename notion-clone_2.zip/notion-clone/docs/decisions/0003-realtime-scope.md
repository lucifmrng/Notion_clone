# ADR 0003 — Realtime scope: presence + page updates + live cursors

## Status
Accepted.

## Context
"Realtime" can mean a lot of different things. Each surface has a separate
cost: client wiring, server infrastructure, and ongoing complexity.

Surfaces considered:
- **Page updates** — edits propagate between collaborators (the editor itself).
- **Live cursors** — show other users' cursor positions and selections in the editor.
- **Presence** — show who is currently viewing/editing a page.
- **Sidebar realtime** — sibling page tree updates as collaborators add/rename pages.
- **Comments / mentions / notifications** — out of scope.

## Decision
Page updates, live cursors, and presence. No sidebar realtime in this
session; the sidebar refreshes on navigation.

## Consequences

**Live cursors require Yjs awareness, not just sync.** Hocuspocus speaks
the awareness protocol natively, so this is mostly client-side wiring.
The editor's `CollaborationCursor` extension consumes it.

**Sidebar realtime would mean a second realtime channel** (Supabase
Realtime on `pages` table changes), filtered by workspace. It's not hard,
but it's another surface to keep in sync with RLS — Supabase Realtime
filters via the same RLS policies as the REST API, so the security
boundary holds, but adding a fourth realtime concept (after Yjs sync,
Yjs awareness, and presence) for a low-value UX win is the wrong order
of priorities.

## Revisit when
- The product needs comments → reuse the Hocuspocus channel by adding a
  comments Y.Map to the same document.
- The product needs notifications → Supabase Realtime broadcast on a
  per-user channel.
- The sidebar staleness becomes a complaint → add Supabase Realtime
  subscription on `pages` filtered by `workspace_id`.
