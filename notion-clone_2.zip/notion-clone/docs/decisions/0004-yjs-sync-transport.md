# ADR 0004 — Yjs sync transport: Hocuspocus

## Status
Accepted.

## Context
Yjs needs a sync provider — something that moves CRDT updates between
clients and persists state. With Supabase already in the stack, two
realistic options:

1. **`y-supabase`** — a community provider that broadcasts Yjs updates
   over Supabase Realtime channels and persists snapshots to Postgres.
   No extra service to deploy.

2. **Hocuspocus** — a purpose-built Yjs server. Mature, maintained, has a
   first-class database extension. Requires a separate Node service.

## Decision
Hocuspocus.

## Why

**Per-document authorization.** Hocuspocus's `onAuthenticate` hook runs
*before* a client joins a room. We validate the Supabase JWT and check
workspace membership in the same handshake. With `y-supabase`, the
authorization story is "RLS on the Realtime channel," which works but is
harder to audit — the sync layer is no longer separate from the data layer.

**Awareness protocol for cursors.** Native in Hocuspocus. Doable in
`y-supabase` but more tightly coupled to the broadcast layer.

**Persistence semantics we own less of.** Hocuspocus's Database extension
debounces writes for us. We just supply load/store. The extension's
contract is small enough that the persistence code in `hocuspocus/src/index.ts`
fits in one file.

**Predictable scaling.** A Hocuspocus node handles thousands of rooms.
Beyond that there's a Redis extension for cross-node awareness. With
Realtime channels, scaling concerns are coupled to the Supabase plan in
ways that aren't ours to control.

## Costs

**Three deploy targets instead of two.** Documented in `README.md`.
The Dockerfile is in `hocuspocus/`; any Node host (Railway, Fly, Render,
Cloud Run) is fine.

**A direct Postgres connection for Hocuspocus persistence.** Service-role
Supabase client doesn't fit — we need transactions for the
`page_yjs_state` upsert + `pages.content_text` update. Use the Supabase
"Session" mode connection string (not the pooler).

## Alternatives rejected
- `y-supabase`: third-party sync, ambiguous auth boundary, persistence
  story we'd own anyway.
- Custom `y-websocket` server: reinventing what Hocuspocus already gives us.
- `y-webrtc` (peer-to-peer, no server persistence): no source of truth,
  no offline join, no auth gate.
