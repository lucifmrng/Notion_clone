# ADR 0001 — Tenancy model: Orgs → Workspaces → Pages

## Status
Accepted.

## Context
The product needs multi-tenant isolation. Three reasonable shapes:

1. **Single tenant** (workspaces only). Simplest. Doesn't model paid teams
   or B2B billing units cleanly.
2. **Two tier** (workspaces → pages, with workspaces as the billing
   boundary). Slack-like.
3. **Three tier** (orgs → workspaces → pages). Notion-like, GitHub-like.
   Org is the billing/admin boundary; workspaces are functional units.

## Decision
Three tier. Org owns billing, members, and policies. Workspaces are
functional groupings with their own member subsets. Not every org member
is in every workspace.

## Consequences

**Cost.** Two membership tables (`org_members`, `workspace_members`),
two-step joins for any "is this user allowed" question, and an extra layer
of role logic.

**Mitigation: denormalize.** Every tenant-scoped table carries `org_id`
and `workspace_id`. RLS policies become single-table membership checks
against helper functions. We pay a few bytes per row for cheap, auditable
policies.

**Mitigation: bootstrap policies.** First-org and first-workspace creation
needs to bypass the "only admins can add members" rule, since there are no
admins yet. Two narrowly-scoped policies permit self-insert-as-owner when
the table has no rows for that scope. See `0002_rls.sql`.

## Alternatives rejected
- Workspaces-only would have forced us to revisit auth and billing
  on the first enterprise customer. Cheaper to model orgs upfront.
- Putting RLS at the join layer (no denormalization) was tested and rejected;
  policies become hard to read and prone to recursion bugs.
