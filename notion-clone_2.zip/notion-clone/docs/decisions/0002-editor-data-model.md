# ADR 0002 — Editor data model: Yjs CRDT

## Status
Accepted.

## Context
Three reasonable models for collaborative editing:

1. **Last-write-wins on a JSON document.** Simple. Dies on concurrent edits.
2. **OT (Operational Transform).** Battle-tested (Google Docs). Heavy to
   implement; transforms are subtle.
3. **CRDT, specifically Yjs.** Conflict-free by construction. Mature
   ecosystem with `y-prosemirror` for Tiptap.

## Decision
Yjs CRDT, persisted as binary state to Postgres.

## Consequences

**Wins.** True multiplayer with offline-tolerant merging. Cursor and
selection sharing is already part of Yjs awareness — live cursors come
nearly free. The schema needs only one new table (`page_yjs_state`).

**Costs.** A Yjs document can drift from a "clean" tree representation
over time as updates accumulate. The `state` column stores the merged
binary state, not a log of updates, which keeps the DB small at the cost
of losing per-update history.

**Costs.** The browser holds a full copy of the document's CRDT state.
For document sizes typical of a wiki this is fine; for very large
documents (megabytes) we'd reconsider.

**Costs.** A search-friendly text projection is not free — we extract
plaintext from the Y.Doc on every persistence and write it to
`pages.content_text`. See ADR 0004 (sync transport).

## Alternatives rejected
- LWW on JSON: not viable for a real editor.
- OT: more code to write and maintain, no ecosystem upside over Yjs for
  this stack.
- Storing Yjs as an append-only update log instead of merged state: useful
  if we needed time-travel; we don't, and it complicates compaction.
