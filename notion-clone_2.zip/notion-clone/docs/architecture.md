# Architecture

## Three-tier tenancy

```
orgs
 └── org_members (user_id, role: owner|admin|member)
 └── workspaces
      └── workspace_members (user_id, role: owner|admin|member)
      └── pages (tree via parent_id)
           └── page_yjs_state (binary Y.Doc)
```

Every tenant-scoped table denormalizes `org_id` and `workspace_id`. RLS
policies are single-table membership checks against `is_workspace_member()`
or `is_org_admin()` rather than join chains. The cost is a few bytes per row
and a denormalization invariant; the win is policies that are cheap, easy
to audit, and free of recursion bugs.

## Auth boundary at the layout

`src/app/(app)/w/[workspaceId]/layout.tsx` queries the workspace once. RLS
is the access check — if the user isn't a member, the query returns null and
the layout calls `notFound()`. Every page beneath the layout inherits the
guarantee. This avoids scattered membership checks in individual components.

`middleware.ts` runs `updateSession`, which validates the JWT via
`supabase.auth.getUser()` (not `getSession()` — `getSession` only reads the
cookie without verifying it) and redirects unauthenticated traffic on
protected paths.

## Real-time editing

The editor is Tiptap on a Yjs CRDT. Browsers open a WebSocket to a
Hocuspocus server, which is a separate Node service.

Why a separate service: Supabase Realtime is a Postgres change stream and a
broadcast channel; it is not a Yjs sync provider. Wiring CRDT updates over
Realtime channels is possible (see `y-supabase`) but you'd own snapshot
compaction and the persistence story. Hocuspocus is purpose-built, has a
mature Database extension, and gets the security-critical pieces right
(per-document auth, awareness for cursors). The cost is a third deploy
target.

### Auth handshake

```
Browser                    Hocuspocus                   Supabase
   │                          │                            │
   ├── WS connect ───────────▶│                            │
   │   doc=workspaceId:pageId │                            │
   │   token=supabaseJWT      │                            │
   │                          ├── auth.getUser(jwt) ──────▶│
   │                          │◀── user_id ────────────────┤
   │                          │                            │
   │                          ├── rpc(is_workspace_member)▶│
   │                          │◀── boolean ────────────────┤
   │                          │                            │
   │                          ├── verify page belongs to workspace (Postgres)
   │                          │                            │
   │◀── accept (or reject) ───┤                            │
```

Document name format: `<workspaceId>:<pageId>`. Both must be UUIDs; see
`hocuspocus/src/document-name.ts` and its tests.

### Persistence

Hocuspocus's Database extension reads/writes `page_yjs_state.state` (bytea)
on debounced writes. In the same transaction, the server extracts plaintext
from the Y.Doc and updates `pages.content_text`, which feeds the search
index. This keeps search and editor state consistent without a second
write path.

## Search

Postgres `tsvector` with the English config, generated from `title` (weight A)
and `content_text` (weight B). GIN index. Search runs through a SQL
`SECURITY INVOKER` function so the existing `pages` RLS still applies — there
is no separate access-control layer for search.

Snippets come from `ts_headline`. The HTML it returns is server-generated
and bounded; we render with `dangerouslySetInnerHTML` which is acceptable
for that input.

## Reporting

`analytics_events` is append-only, written by triggers on `pages` (insert /
update / delete). A materialized view `mv_daily_page_activity` aggregates
events by day and event type; refreshed via `refresh_reporting_aggregates()`,
either manually from the dashboard or scheduled (e.g. `pg_cron`).

The reporting dashboard fetches in three parallel server queries:
- Daily activity (last 30 days) — bucketed in TypeScript for chart-axis
  filling. Pure function in `bucket.ts`, tested.
- Top contributors — `v_top_contributors_30d`, sorted client-side.
- Pages per workspace — fan-out of `head:true` count queries, fine for the
  small workspace cardinality this is sized for. For an org with thousands
  of workspaces, push to a SQL view.

## Why feature folders, not type folders

`src/features/<domain>/` — each owning its server actions, UI components,
and helpers — scales better than `components/`, `actions/`, `lib/` typed by
layer. By the time you have ten features, type-by-layer becomes a
flat-namespace problem; type-by-feature stays bounded.

`components/ui/` is reserved for primitives (shadcn-style), shared across
features. `lib/` is for cross-cutting infrastructure (Supabase, utils, db
types).

## What is deliberately small

- One `migrations/` directory, raw SQL, no ORM. Supabase RLS is SQL anyway,
  and an ORM would hide what the database is doing.
- Hand-written `db/types.ts` — would normally be `supabase gen types`.
- No state management library. Server Components and Server Actions push
  state to where it's authoritative; the editor uses Yjs which has its own
  state model. `useState` is enough for the few client islands.
