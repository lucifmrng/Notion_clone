# Observability

This document is the source of truth for what gets emitted, where it
goes, and what is deliberately not captured. Update it whenever you add a
new metric or log field that other people will rely on.

## Pipeline

```
┌─────────────────┐     dd-trace      ┌──────────────┐     ┌──────────┐
│ Next.js / Hocus │ ─── traces  ────▶ │   Datadog    │     │          │
│      pocus      │ ─── metrics ────▶ │    Agent     │ ──▶ │ Datadog  │
│                 │ ─── runtime ────▶ │ (sidecar or  │     │   SaaS   │
│                 │                   │   per-host)  │     │          │
│                 │ ─── stdout  ────▶ │  (logs tail) │ ──▶ │          │
│                 │                                        │          │
│                 │ ─── @sentry/* ─────────────────────▶   │  Sentry  │
└─────────────────┘                                        └──────────┘
```

- **Traces, metrics, logs → Datadog** via the Datadog Agent. The agent
  runs as a sidecar in container deploys or per-host elsewhere. See
  `https://docs.datadoghq.com/agent/`.
- **Errors → Sentry**, separately. Sentry's grouping and triage UI is
  better than what the OTel-style backends offer right now.
- **No double-counting.** Sentry tracesSampleRate is 0; only errors flow
  through Sentry.

## Logs

All logs are JSON in production (pino), pretty-printed in development.

### Standard fields (every line)

| field | description |
|---|---|
| `level`, `status` | log level (`status` is for Datadog) |
| `service` | `notion-clone-web` or `notion-clone-hocuspocus` |
| `env` | `production`, `staging`, `development` |
| `version` | release version (matches Sentry release tag) |
| `time` | ISO timestamp |
| `dd.trace_id`, `dd.span_id` | injected when in a traced context |

### Common fields by context

| field | when | example |
|---|---|---|
| `request_id` | per-request scope (Next.js routes/actions) | uuid |
| `route` | per-route handler | `GET /api/search` |
| `user_id` | authenticated request | uuid |
| `workspace_id` | workspace-scoped operation | uuid |
| `page_id` | page-scoped operation | uuid |
| `documentName` | Hocuspocus events | `<wsId>:<pageId>` |
| `outcome` | terminal events | `success`, `error`, `unauthorized` |
| `duration_ms` | timed operations | number |

### Redaction

The pino logger is configured to redact known-sensitive paths
(`*.password`, `*.token`, `*.access_token`, `*.refresh_token`,
`*.authorization`, `req.headers.cookie`, etc.). This is defense in
depth, not the primary defense — don't log secrets in the first place.
See `src/lib/observability/logger.ts` for the full list.

### Things we explicitly do not log

- Document content (Y.Doc binary state, plaintext snapshots)
- Email bodies
- Auth tokens, JWTs, service-role keys
- Full request/response bodies
- Search query strings (logged as `query_length` only)

## Metrics

Naming convention: `notion.<domain>.<metric>` snake_case.

### Web app

| metric | type | tags | meaning |
|---|---|---|---|
| `notion.search.request` | counter | outcome | search requests by outcome |
| `notion.search.query.duration_ms` | histogram | scope, outcome | search latency |
| `notion.search.result_count` | histogram | — | result count distribution |

### Hocuspocus

| metric | type | tags | meaning |
|---|---|---|---|
| `notion.hocuspocus.auth` | counter | outcome | auth attempts by outcome |
| `notion.hocuspocus.auth.duration_ms` | histogram | — | auth handshake latency |
| `notion.hocuspocus.connect` | counter | — | connection accepts |
| `notion.hocuspocus.disconnect` | counter | — | disconnects |
| `notion.hocuspocus.active_connections` | gauge | — | currently open WS connections |
| `notion.hocuspocus.fetch.duration_ms` | histogram | hit | document load latency |
| `notion.hocuspocus.store.duration_ms` | histogram | outcome | document save latency |
| `notion.hocuspocus.store.state_bytes` | histogram | — | persisted Y.Doc size |
| `notion.hocuspocus.pg_pool.total` | gauge | — | total pg connections |
| `notion.hocuspocus.pg_pool.idle` | gauge | — | idle pg connections |
| `notion.hocuspocus.pg_pool.waiting` | gauge | — | requests waiting for a pg connection |

### Tag cardinality discipline

Tags are low-cardinality by design. Never tag a metric with `user_id`,
`page_id`, `workspace_id`, or any other identifier. Use logs for
high-cardinality fields. Datadog bills per metric series; a `user_id` tag
turns one metric into millions.

## Traces

dd-trace auto-instruments:
- HTTP (inbound, outbound)
- Next.js (RSC, route handlers, server actions)
- Postgres (every query, with statement shape, no literals)
- Supabase HTTP (via undici)

Sample rate defaults to 10% (`DD_TRACE_SAMPLE_RATE`). Errors are always
captured regardless of sample. Adjust at the route level via
`tracer.scope().active()?.setTag('manual.keep')` for paths where 100%
matters (auth, payment).

Health-check paths (`/api/health`, `/health`) are blocklisted to prevent
LB pings from dominating trace volume.

## Errors (Sentry)

Captured automatically:
- Unhandled exceptions in route handlers and server actions
- Server Component render errors
- Client-side unhandled promise rejections
- Hocuspocus `Sentry.captureException()` calls in critical paths

Filtered intentionally:
- `NEXT_REDIRECT`, `NEXT_NOT_FOUND` (control flow, not errors)
- Browser noise (`ResizeObserver loop limit exceeded`, etc.)
- Editor WebSocket reconnect errors (transient)

User context: `user_id` only. Email is scrubbed in `beforeSend`.

## Health checks

| endpoint | purpose | recommended frequency |
|---|---|---|
| `GET /api/health` | Next.js liveness | LB: 5s |
| `GET /api/health?deep=1` | Next.js readiness (probes Postgres) | k8s readiness: 30s |
| `GET :1235/health` | Hocuspocus liveness | LB: 5s |
| `GET :1235/health?deep=1` | Hocuspocus readiness | k8s readiness: 30s |

Don't use deep health checks as your LB target health probe — slow
checks become outages.

## Dashboards

JSON dashboard definitions live in `observability/dashboards/`. Import
into Datadog via UI → New Dashboard → Import.

- `golden-signals.json` — latency, traffic, errors, saturation per service
- `hocuspocus.json` — Hocuspocus-specific (connections, persistence)
- `database.json` — Postgres health (pool state, query duration)

## Adding a new metric

1. Pick a name following `notion.<domain>.<metric>` snake_case.
2. Add to the table in this doc.
3. Keep tags low-cardinality.
4. Wire it via `metrics.increment / gauge / histogram` from
   `src/lib/observability/metrics.ts`.

## Adding a new log field

1. If it's PII or sensitive, don't add it. Use an opaque ID instead.
2. If it's high-cardinality (UUID), it's a log field, not a metric tag.
3. Update the "Common fields" table above.
