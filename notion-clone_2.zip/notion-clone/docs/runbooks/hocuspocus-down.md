# Runbook: Hocuspocus is down

**Symptoms.** Editor shows "Offline" indicator. Active connections gauge
(`notion.hocuspocus.active_connections`) drops to 0. Users can't open
documents or see live cursors.

**User-visible impact.** Editor degrades to a static view of the last-saved
state. Edits made while disconnected are kept in the local Yjs doc and will
sync on reconnect — no data loss unless the browser is closed before the
service recovers.

## First five minutes

1. **Confirm scope.** Is it one node or all of them?
   - Datadog → Service map → `notion-clone-hocuspocus` → check instance count.
   - If only some instances: investigate the bad one, route traffic away.
   - If all: continue to step 2.

2. **Check the obvious.**
   - Datadog Logs → filter `service:notion-clone-hocuspocus status:fatal`
     for the last 30 minutes.
   - Sentry → recent issues tagged `notion-clone-hocuspocus`.
   - Look for `unhandled promise rejection`, `uncaught exception`,
     `postgres pool error`.

3. **Check Postgres.** Most Hocuspocus crashes upstream of code bugs are
   actually Postgres connectivity.
   - `notion.hocuspocus.pg_pool.waiting` spiking → connection exhaustion.
   - `notion.hocuspocus.pg_pool.total` at zero → pool died, likely Postgres
     restarted or rejected our credentials.

4. **Restart.** If the cause is unclear and active_connections is 0,
   restart the service. The Yjs state in Postgres is the source of truth;
   nothing is lost on restart.

## Common causes

### Postgres restarted (Supabase maintenance, network blip)
**Detect.** `pg_pool.total` drops to 0, `postgres pool error` logs.
**Fix.** The pool reconnects automatically. If clients show stale errors,
roll the Hocuspocus pods.

### Memory exhaustion
**Detect.** Datadog runtime metrics → `runtime.node.heap.total` climbing
monotonically over hours/days. OOMKill in container logs.
**Fix.** Short term: bump container memory limit. Long term: investigate
which document is unusually large (`notion.hocuspocus.store.state_bytes`
histogram → p99). A single multi-MB document held in memory for many
concurrent users adds up.

### Auth provider down (Supabase auth API unavailable)
**Detect.** `notion.hocuspocus.auth` with `outcome:rpc_error` spikes.
**Fix.** Out of our control. Status page → Supabase. Existing connections
keep working; new connections fail until upstream recovers.

### Bad deploy
**Detect.** Issue starts within minutes of a release. Sentry release tag
matches the bad version.
**Fix.** Roll back. Don't debug forward in an incident.

## Escalation

After 15 minutes of no progress, page on-call backup. Bring:
- Sentry issue link
- Datadog log query showing the first failures
- Recent deploys / config changes
- Whether Postgres is healthy independently
