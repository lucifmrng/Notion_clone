# Runbook: Authentication flapping

**Symptoms.** Users report being logged out unexpectedly. Sign-in succeeds
then immediately bounces. `notion.hocuspocus.auth` with
`outcome:invalid_token` spikes. Sentry shows unusual rate of NEXT_REDIRECT
in protected routes (when ignored, you'll see them as 302→login in
access logs).

**User-visible impact.** Anywhere from "had to log in again" to "can't
stay logged in at all."

## First five minutes

1. **Confirm scope.**
   - Datadog → search logs for `service:notion-clone-web "invalid token"`.
   - Sentry → spike in auth-related errors.
   - Is it everyone or a subset (one tenant, one device type)?

2. **Check Supabase auth.**
   - Supabase project → Auth → look for recent JWT secret rotation or
     provider config changes.
   - Status page: status.supabase.com for the auth service.

3. **Check the bridge between Next.js and Hocuspocus.**
   - The browser passes its Supabase access token to Hocuspocus on connect.
   - Tokens are short-lived (default 1 hour). The Supabase client refreshes
     them automatically via the middleware. If the middleware isn't
     running on a route (matcher gap), tokens go stale.

## Common causes

### Middleware matcher excluded a route it shouldn't
**Detect.** Specific routes log out users; others don't. The matcher in
`src/middleware.ts` uses a regex; a recent change might have over-excluded.
**Fix.** Test by hitting the route, watching `set-cookie` headers.
Middleware should always set the refreshed `sb-*-auth-token` cookies.

### Clock skew between Next.js host and Supabase
**Detect.** "JWT not yet valid" or "JWT expired" errors at high rate.
**Fix.** Sync system clocks via NTP. Modern hosts almost never have this
problem; bare-metal or VMs without NTP do.

### JWT secret rotation
**Detect.** All users logged out simultaneously, including freshly issued
tokens. Coincides with Supabase config change.
**Fix.** Wait for users to re-authenticate. Don't roll back — the rotation
was probably intentional.

### Session cookie domain mismatch
**Detect.** Login succeeds but subsequent requests act anonymous.
SameSite/Domain policy preventing the cookie from being sent.
**Fix.** Check `NEXT_PUBLIC_APP_URL` matches the actual served domain
including subdomain. Cross-subdomain cookies need explicit Domain=.

### Hocuspocus rejecting valid tokens
**Detect.** Web works, but editor shows "Offline". Hocuspocus logs show
`invalid token` for tokens that are accepted by Next.js.
**Fix.** Confirm Hocuspocus and Next.js point at the same Supabase
project. Mismatched `NEXT_PUBLIC_SUPABASE_URL` between services is the
classic config drift.

## Don't panic if

- You see a small steady rate of `invalid_token` outcomes. There's always
  some baseline from expired tabs, stale curl scripts, and bots probing.
  The signal is a *spike* relative to normal, not the absolute count.
