# Runbook: Search timing out

**Symptoms.** `/api/search` returning 500s or 504s. p95 of
`notion.search.query.duration_ms` over 3s. Search box shows
"Search failed" or just hangs.

**User-visible impact.** Search is broken or slow. Editor still works.

## First five minutes

1. **Sample a few failing queries.**
   - Datadog Logs → `service:notion-clone-web route:"GET /api/search" status:error`.
   - What query strings are failing? One query, all queries, certain workspaces?

2. **Run the query directly.**
   - Open a SQL editor in Supabase.
   - `select * from search_pages('the failing query', null, 20);`
   - If this hangs, the problem is database-side.
   - If it returns instantly, the problem is between the API and the DB.

3. **Check Postgres.** If the direct query is slow, see
   `postgres-slow.md`.

## Common causes

### Query is too broad
**Detect.** A user searches for `the` or `and` — `websearch_to_tsquery`
matches almost everything.
**Fix.** The search RPC limits to 20 by default. If hits are still in the
millions, ranking is the bottleneck. Add a stop-word list: switch the
text search config from `english` to a custom config that strips short
common terms.

### Index bloat
**Detect.** `search_pages` is slow even for narrow queries; EXPLAIN shows
the GIN index but a high cost.
**Fix.** `vacuum analyze pages;` in a maintenance window. If chronic,
schedule autovacuum more aggressively for `pages`.

### `content_text` field is megabytes
**Detect.** A handful of pages have absurd `content_text` length, slowing
ts_headline.
**Fix.** Hocuspocus caps plaintext at 200KB on save (see
`extractPlaintext`). If pre-existing pages exceed this, run a one-off
truncation:
```sql
update pages set content_text = substring(content_text, 1, 200000)
where length(content_text) > 200000;
```

### Search RPC has incorrect grant
**Detect.** Logs show `permission denied for function search_pages`.
**Fix.** `grant execute on function search_pages(text, uuid, int) to authenticated;`
This is in the migrations; if it got dropped in a manual schema change,
re-grant.

## Graceful degradation

The search UI doesn't block the rest of the app. If search is down,
users can still use direct page navigation, the sidebar tree, and the
"recent pages" list on the dashboard.

If search is degraded but not down, prefer to disable it briefly rather
than serve consistently slow responses — slow search trains users to
distrust the feature.
