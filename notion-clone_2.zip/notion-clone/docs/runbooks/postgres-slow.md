# Runbook: Postgres is slow

**Symptoms.** p95 of `notion.search.query.duration_ms` over 1s.
`notion.hocuspocus.store.duration_ms` p95 over 2s. Pages take long to
load. `notion.hocuspocus.pg_pool.waiting` non-zero.

**User-visible impact.** Search feels sluggish. Editor save indicator
("Saving...") sticks for noticeable time. New page creation slow.

## First five minutes

1. **Triage by query.** Datadog APM → service `notion-clone-postgres` →
   sort traces by duration. Which queries are slow? Almost always one of:
   - `search_pages` RPC (full-text search hitting too many rows)
   - Sidebar page-tree query (`select * from pages where workspace_id=...`)
   - Hocuspocus `store` upsert (slow if `page_yjs_state` is bloated)
   - Reporting fan-out (`getPageCountsByWorkspace` issues N count queries)

2. **Check Supabase.** Project dashboard → Database → Performance.
   - High CPU, low cache hit ratio → query pattern problem.
   - High disk I/O, low CPU → working set doesn't fit in RAM.
   - Connection count near limit → pooler saturated.

3. **Look at `pg_stat_statements`.**
   ```sql
   select query, calls, mean_exec_time, total_exec_time
   from pg_stat_statements
   order by total_exec_time desc
   limit 20;
   ```
   Top entries by `total_exec_time` are the actual cost drivers, regardless
   of how slow each call is.

## Common causes

### Missing index on a hot path
**Detect.** A simple-looking query in `pg_stat_statements` with high mean
time. EXPLAIN shows Seq Scan.
**Fix.** Add the index. For predicates like `where workspace_id = X and is_archived = false`
you want `(workspace_id, is_archived) where is_archived = false`.

### Materialized view never refreshed
**Detect.** Reporting dashboard shows stale data; `mv_daily_page_activity`
`last_refresh` is hours old.
**Fix.** Run `select refresh_reporting_aggregates();` manually.
Schedule via `pg_cron` to prevent recurrence.

### Reporting fan-out at scale
**Detect.** Reporting page p95 climbs as workspace count grows. APM shows
`getPageCountsByWorkspace` issuing many parallel queries.
**Fix.** This is a known issue (see `docs/decisions/` for context). Replace
the Promise.all loop with a single `select workspace_id, count(*) ... group by workspace_id`.

### `analytics_events` unbounded growth
**Detect.** Reporting queries slow down monotonically over months. Table
size in Supabase dashboard climbing.
**Fix.** Partition by month; drop or archive partitions older than retention.

### Connection saturation
**Detect.** `pg_pool.waiting > 0` sustained. Supabase project at connection
limit.
**Fix.** Tune `PG_POOL_MAX` per Hocuspocus instance to not exceed
`(supabase_max_conns / instance_count)`. Use Supavisor/PgBouncer for the
Next.js side.

## Escalation

If queries that used to be fast are suddenly slow with no change to the
data or schema: suspect Postgres maintenance, autovacuum starvation, or
a bad query plan. Run `analyze` on the affected tables. If still slow,
escalate to Supabase support with a `pg_stat_statements` snapshot.
