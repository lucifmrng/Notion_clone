# Schema

Source of truth: `supabase/migrations/0001_init.sql` and `0002_rls.sql`.

## Tables

### `profiles`
Public-safe mirror of `auth.users`. Populated by trigger on insert.
| column | type | notes |
|---|---|---|
| id | uuid PK | FK auth.users.id |
| email | text | |
| display_name | text | |
| avatar_url | text | |

### `orgs`
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| name | text | |
| slug | text UNIQUE | |
| created_by | uuid | FK profiles.id |

### `org_members`
| column | type | notes |
|---|---|---|
| (org_id, user_id) | PK | |
| role | enum | owner / admin / member |

### `workspaces`
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| org_id | uuid | FK orgs.id |
| name, slug, icon | | unique (org_id, slug) |
| created_by | uuid | |

### `workspace_members`
| column | type | notes |
|---|---|---|
| (workspace_id, user_id) | PK | |
| org_id | uuid | denormalized; matches workspaces.org_id |
| role | enum | owner / admin / member |

### `pages`
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| org_id, workspace_id | uuid | denormalized for RLS |
| parent_id | uuid | self-FK; null at root |
| title, icon | text | |
| content_text | text | plaintext snapshot, kept in sync by Hocuspocus on save |
| is_archived | bool | |
| position | float8 | fractional index for sibling ordering |
| search_vector | tsvector | GENERATED from title (A) + content_text (B) |

### `page_yjs_state`
| column | type | notes |
|---|---|---|
| page_id | uuid PK | FK pages.id |
| org_id, workspace_id | uuid | denormalized |
| state | bytea | binary Y.Doc state, written by Hocuspocus |

### `invites`, `analytics_events`
See migration. Invites are scaffolded but email delivery is out of scope.
`analytics_events` is append-only, populated by triggers.

## Helper functions (SECURITY DEFINER)

These exist to break the RLS recursion problem: a policy on `org_members`
cannot itself query `org_members` under RLS. SECURITY DEFINER bypasses RLS
inside the function body so the membership lookup completes.

```sql
is_org_member(p_org_id, p_user_id default auth.uid()) → bool
is_org_admin(p_org_id, p_user_id default auth.uid()) → bool
is_workspace_member(p_workspace_id, p_user_id default auth.uid()) → bool
is_workspace_admin(p_workspace_id, p_user_id default auth.uid()) → bool
```

`auth.uid()` defaults make these convenient inside policies where the
caller is implicit.

## RLS policies — summary

| table | who can read | who can write |
|---|---|---|
| profiles | self + org-mates | self update only |
| orgs | members | members create; admins update; owners delete |
| org_members | members of same org | admins manage; users can self-leave; bootstrap policy permits the creator to insert themselves as owner when the org has no members |
| workspaces | org members | org members create; workspace admins or org admins update; workspace owners or org admins delete |
| workspace_members | workspace members | workspace admins or org admins manage; users can self-leave; bootstrap mirrors org_members |
| pages | workspace members | workspace members create/update; workspace admins or org admins delete |
| page_yjs_state | workspace members read | service role only writes (Hocuspocus) |
| invites | org/workspace admins | org/workspace admins create and revoke |
| analytics_events | workspace members for workspace events; org members for org-only events | trigger / service role only |

## Bootstrap policy detail

A user creating their first org needs to insert themselves into
`org_members` as `owner`. The "admins manage" policy fails because there
are no admins yet. The bootstrap policy permits a self-insert as `owner`
when no other members exist on that org. Same pattern for workspaces.

The subqueries inside these policies alias the table (`existing`) to
disambiguate the inner reference from the candidate row's columns.

## Search RPC

```sql
search_pages(p_query text, p_workspace_id uuid default null, p_limit int default 20)
```

`SECURITY INVOKER` — RLS on `pages` still applies, so callers see only
pages they have access to. Returns ranked rows with `ts_headline` snippets.

## Materialized view + refresh

```sql
mv_daily_page_activity (org_id, workspace_id, day, event_type, event_count, distinct_users)
```

Refresh via `refresh_reporting_aggregates()`. For production, schedule with
`pg_cron` every 15 minutes; the refresh button in the dashboard is a
fallback for environments without it.

## Indexes worth knowing

- `pages_workspace_parent_position_idx` (workspace_id, parent_id, position)
  partial-where `is_archived = false` — covers the sidebar's primary access
  pattern.
- `pages_search_vector_idx` GIN — full-text search.
- `analytics_events_workspace_created_idx` — reporting time-series queries.
- `mv_daily_page_activity_uniq` UNIQUE (org_id, workspace_id, day, event_type)
  — required for `refresh materialized view CONCURRENTLY`.
