-- =============================================================================
-- 0003_search.sql — Full-text search via tsvector
-- =============================================================================
-- Strategy:
--   - Generated column on pages: search_vector = title + content_text.
--   - GIN index for fast lookup.
--   - Plaintext content_text is updated by the application on document save
--     (Hocuspocus extracts text from the Y.Doc and writes both `state` bytea
--     and `content_text` plaintext in the same transaction).
-- =============================================================================

alter table pages
  add column search_vector tsvector
  generated always as (
    setweight(to_tsvector('english', coalesce(title, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(content_text, '')), 'B')
  ) stored;

create index pages_search_vector_idx on pages using gin (search_vector);

-- ---------------------------------------------------------------------------
-- Search RPC. Returns ranked results scoped to workspaces the caller belongs to.
-- Using a SECURITY INVOKER function so RLS on `pages` still applies.
-- ---------------------------------------------------------------------------
create or replace function search_pages(
  p_query text,
  p_workspace_id uuid default null,
  p_limit int default 20
)
returns table (
  id uuid,
  workspace_id uuid,
  title text,
  snippet text,
  rank real,
  updated_at timestamptz
)
language sql
stable
security invoker
set search_path = public
as $$
  select
    p.id,
    p.workspace_id,
    p.title,
    ts_headline(
      'english',
      coalesce(p.content_text, ''),
      websearch_to_tsquery('english', p_query),
      'MaxWords=20, MinWords=5, ShortWord=3, MaxFragments=2'
    ) as snippet,
    ts_rank(p.search_vector, websearch_to_tsquery('english', p_query)) as rank,
    p.updated_at
  from pages p
  where p.is_archived = false
    and (p_workspace_id is null or p.workspace_id = p_workspace_id)
    and p.search_vector @@ websearch_to_tsquery('english', p_query)
  order by rank desc, p.updated_at desc
  limit p_limit;
$$;

-- =============================================================================
-- Analytics: triggers + materialized view
-- =============================================================================

create or replace function log_page_event()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_event analytics_event_type;
  v_user uuid;
begin
  v_user := auth.uid();
  if (tg_op = 'INSERT') then
    v_event := 'page.created';
    insert into analytics_events (org_id, workspace_id, page_id, user_id, event_type)
    values (new.org_id, new.workspace_id, new.id, v_user, v_event);
    return new;
  elsif (tg_op = 'UPDATE') then
    -- Only log content/title changes, not housekeeping like is_archived flips
    if (new.title is distinct from old.title or new.content_text is distinct from old.content_text) then
      insert into analytics_events (org_id, workspace_id, page_id, user_id, event_type)
      values (new.org_id, new.workspace_id, new.id, v_user, 'page.updated');
    end if;
    return new;
  elsif (tg_op = 'DELETE') then
    insert into analytics_events (org_id, workspace_id, page_id, user_id, event_type)
    values (old.org_id, old.workspace_id, null, v_user, 'page.deleted');
    return old;
  end if;
  return null;
end;
$$;

create trigger pages_log_events
  after insert or update or delete on pages
  for each row execute function log_page_event();

-- ---------------------------------------------------------------------------
-- Daily aggregate materialized view.
-- Refresh strategy: see refresh_reporting_aggregates() below.
-- For production, schedule via pg_cron every 15 minutes.
-- ---------------------------------------------------------------------------
create materialized view mv_daily_page_activity as
select
  org_id,
  workspace_id,
  date_trunc('day', created_at) as day,
  event_type,
  count(*)::bigint as event_count,
  count(distinct user_id)::bigint as distinct_users
from analytics_events
where workspace_id is not null
group by org_id, workspace_id, date_trunc('day', created_at), event_type;

create unique index mv_daily_page_activity_uniq
  on mv_daily_page_activity (org_id, workspace_id, day, event_type);

create index mv_daily_page_activity_workspace_day_idx
  on mv_daily_page_activity (workspace_id, day desc);

-- ---------------------------------------------------------------------------
-- Top contributors view (last 30 days, by workspace).
-- Plain view (not materialized) — small enough to compute on demand.
-- ---------------------------------------------------------------------------
create or replace view v_top_contributors_30d as
select
  ae.org_id,
  ae.workspace_id,
  ae.user_id,
  p.display_name,
  p.email,
  count(*) filter (where ae.event_type = 'page.created') as pages_created,
  count(*) filter (where ae.event_type = 'page.updated') as pages_updated,
  count(*) as total_events
from analytics_events ae
join profiles p on p.id = ae.user_id
where ae.created_at >= now() - interval '30 days'
  and ae.workspace_id is not null
  and ae.user_id is not null
group by ae.org_id, ae.workspace_id, ae.user_id, p.display_name, p.email;

-- ---------------------------------------------------------------------------
-- Refresh function. Call from server action or pg_cron.
-- ---------------------------------------------------------------------------
create or replace function refresh_reporting_aggregates()
returns void
language sql
security definer
set search_path = public
as $$
  refresh materialized view concurrently mv_daily_page_activity;
$$;

-- Allow authenticated users to call the refresh function. The function itself
-- is SECURITY DEFINER so it runs with elevated privileges; rate-limit at the
-- application layer if abuse becomes a concern.
grant execute on function refresh_reporting_aggregates() to authenticated;
grant execute on function search_pages(text, uuid, int) to authenticated;
grant execute on function is_org_member(uuid, uuid) to authenticated;
grant execute on function is_org_admin(uuid, uuid) to authenticated;
grant execute on function is_workspace_member(uuid, uuid) to authenticated;
grant execute on function is_workspace_admin(uuid, uuid) to authenticated;
