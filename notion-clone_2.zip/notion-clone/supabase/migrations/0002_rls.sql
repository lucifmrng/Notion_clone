-- =============================================================================
-- 0002_rls.sql — Row-Level Security
-- =============================================================================
-- Strategy:
--   1. SECURITY DEFINER helper functions for membership checks. These bypass
--      RLS, which is required to avoid infinite recursion: a policy on
--      org_members cannot itself query org_members under RLS.
--   2. Every tenant-scoped table denormalizes org_id and workspace_id, so
--      policies are single-table membership checks — no joins.
--   3. Policies are role-aware where it matters (delete/admin actions).
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Membership helpers
-- ---------------------------------------------------------------------------
create or replace function is_org_member(p_org_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from org_members
    where org_id = p_org_id and user_id = p_user_id
  );
$$;

create or replace function is_org_admin(p_org_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from org_members
    where org_id = p_org_id
      and user_id = p_user_id
      and role in ('owner', 'admin')
  );
$$;

create or replace function is_workspace_member(p_workspace_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from workspace_members
    where workspace_id = p_workspace_id and user_id = p_user_id
  );
$$;

create or replace function is_workspace_admin(p_workspace_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from workspace_members
    where workspace_id = p_workspace_id
      and user_id = p_user_id
      and role in ('owner', 'admin')
  );
$$;

-- ---------------------------------------------------------------------------
-- Enable RLS
-- ---------------------------------------------------------------------------
alter table profiles enable row level security;
alter table orgs enable row level security;
alter table org_members enable row level security;
alter table workspaces enable row level security;
alter table workspace_members enable row level security;
alter table pages enable row level security;
alter table page_yjs_state enable row level security;
alter table invites enable row level security;
alter table analytics_events enable row level security;

-- ---------------------------------------------------------------------------
-- profiles
-- Anyone authenticated can read profiles of users in their orgs (so they
-- can see "Created by" attribution). Users can update only their own profile.
-- ---------------------------------------------------------------------------
create policy "profiles: read self"
  on profiles for select
  to authenticated
  using (id = auth.uid());

create policy "profiles: read shared org members"
  on profiles for select
  to authenticated
  using (
    exists (
      select 1
      from org_members me
      join org_members them on me.org_id = them.org_id
      where me.user_id = auth.uid()
        and them.user_id = profiles.id
    )
  );

create policy "profiles: update self"
  on profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- ---------------------------------------------------------------------------
-- orgs
-- ---------------------------------------------------------------------------
create policy "orgs: members read"
  on orgs for select
  to authenticated
  using (is_org_member(id));

create policy "orgs: anyone can create"
  on orgs for insert
  to authenticated
  with check (created_by = auth.uid());

create policy "orgs: admins update"
  on orgs for update
  to authenticated
  using (is_org_admin(id))
  with check (is_org_admin(id));

create policy "orgs: owners delete"
  on orgs for delete
  to authenticated
  using (
    exists (
      select 1 from org_members
      where org_id = orgs.id and user_id = auth.uid() and role = 'owner'
    )
  );

-- ---------------------------------------------------------------------------
-- org_members
-- Read: members can see other members of the same org.
-- Insert/update/delete: only org admins, except users can leave (delete self).
-- ---------------------------------------------------------------------------
create policy "org_members: read same org"
  on org_members for select
  to authenticated
  using (is_org_member(org_id));

create policy "org_members: admins manage"
  on org_members for insert
  to authenticated
  with check (is_org_admin(org_id));

create policy "org_members: admins update roles"
  on org_members for update
  to authenticated
  using (is_org_admin(org_id))
  with check (is_org_admin(org_id));

create policy "org_members: admins remove or self leave"
  on org_members for delete
  to authenticated
  using (is_org_admin(org_id) or user_id = auth.uid());

-- Bootstrap: when a user creates an org, they need to insert themselves as owner.
-- The "admins manage" policy fails on first insert because there are no admins
-- yet. Allow self-insert when the inserting row is the user themselves AND
-- the org has no members yet (this is the only legal use).
-- The WITH CHECK predicate runs against the candidate row. The subquery
-- references the same table so we alias to disambiguate; the outer
-- org_members.org_id is the new row's value.
create policy "org_members: self-bootstrap as owner"
  on org_members for insert
  to authenticated
  with check (
    user_id = auth.uid()
    and role = 'owner'
    and not exists (
      select 1 from org_members existing
      where existing.org_id = org_members.org_id
    )
  );

-- ---------------------------------------------------------------------------
-- workspaces
-- ---------------------------------------------------------------------------
create policy "workspaces: org members read"
  on workspaces for select
  to authenticated
  using (is_org_member(org_id));

create policy "workspaces: org members create"
  on workspaces for insert
  to authenticated
  with check (is_org_member(org_id) and created_by = auth.uid());

create policy "workspaces: workspace admins update"
  on workspaces for update
  to authenticated
  using (is_workspace_admin(id) or is_org_admin(org_id))
  with check (is_workspace_admin(id) or is_org_admin(org_id));

create policy "workspaces: workspace owners or org admins delete"
  on workspaces for delete
  to authenticated
  using (
    is_org_admin(org_id)
    or exists (
      select 1 from workspace_members
      where workspace_id = workspaces.id and user_id = auth.uid() and role = 'owner'
    )
  );

-- ---------------------------------------------------------------------------
-- workspace_members
-- ---------------------------------------------------------------------------
create policy "workspace_members: members read"
  on workspace_members for select
  to authenticated
  using (is_workspace_member(workspace_id));

create policy "workspace_members: admins manage"
  on workspace_members for insert
  to authenticated
  with check (is_workspace_admin(workspace_id) or is_org_admin(org_id));

create policy "workspace_members: admins update"
  on workspace_members for update
  to authenticated
  using (is_workspace_admin(workspace_id) or is_org_admin(org_id))
  with check (is_workspace_admin(workspace_id) or is_org_admin(org_id));

create policy "workspace_members: admins remove or self leave"
  on workspace_members for delete
  to authenticated
  using (
    is_workspace_admin(workspace_id)
    or is_org_admin(org_id)
    or user_id = auth.uid()
  );

-- Bootstrap for workspace creator becoming first owner.
create policy "workspace_members: self-bootstrap as owner"
  on workspace_members for insert
  to authenticated
  with check (
    user_id = auth.uid()
    and role = 'owner'
    and not exists (
      select 1 from workspace_members existing
      where existing.workspace_id = workspace_members.workspace_id
    )
  );

-- ---------------------------------------------------------------------------
-- pages
-- Workspace-level access. No page-level ACLs in this session.
-- ---------------------------------------------------------------------------
create policy "pages: workspace members read"
  on pages for select
  to authenticated
  using (is_workspace_member(workspace_id));

create policy "pages: workspace members create"
  on pages for insert
  to authenticated
  with check (
    is_workspace_member(workspace_id)
    and created_by = auth.uid()
  );

create policy "pages: workspace members update"
  on pages for update
  to authenticated
  using (is_workspace_member(workspace_id))
  with check (is_workspace_member(workspace_id));

create policy "pages: workspace admins delete"
  on pages for delete
  to authenticated
  using (is_workspace_admin(workspace_id) or is_org_admin(org_id));

-- ---------------------------------------------------------------------------
-- page_yjs_state
-- Hocuspocus uses the service role key, which bypasses RLS. These policies
-- are defense-in-depth for any direct PostgREST access, which we don't expect.
-- ---------------------------------------------------------------------------
create policy "page_yjs_state: workspace members read"
  on page_yjs_state for select
  to authenticated
  using (is_workspace_member(workspace_id));

-- No insert/update/delete policies for authenticated; only service role writes.

-- ---------------------------------------------------------------------------
-- invites
-- ---------------------------------------------------------------------------
create policy "invites: org admins read"
  on invites for select
  to authenticated
  using (is_org_admin(org_id) or (workspace_id is not null and is_workspace_admin(workspace_id)));

create policy "invites: admins create"
  on invites for insert
  to authenticated
  with check (
    invited_by = auth.uid()
    and (is_org_admin(org_id) or (workspace_id is not null and is_workspace_admin(workspace_id)))
  );

create policy "invites: admins revoke"
  on invites for update
  to authenticated
  using (is_org_admin(org_id) or (workspace_id is not null and is_workspace_admin(workspace_id)))
  with check (is_org_admin(org_id) or (workspace_id is not null and is_workspace_admin(workspace_id)));

-- ---------------------------------------------------------------------------
-- analytics_events
-- Read: anyone with workspace access can read events for that workspace.
-- Write: only via triggers / service role. No INSERT policy for authenticated.
-- ---------------------------------------------------------------------------
create policy "analytics_events: workspace members read"
  on analytics_events for select
  to authenticated
  using (
    workspace_id is null
      and is_org_member(org_id)
    or workspace_id is not null
      and is_workspace_member(workspace_id)
  );
