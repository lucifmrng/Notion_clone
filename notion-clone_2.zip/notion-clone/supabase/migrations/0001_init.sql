-- =============================================================================
-- 0001_init.sql — Core schema
-- =============================================================================
-- Tenancy: Orgs → Workspaces → Pages
-- All tenant-scoped tables denormalize org_id and workspace_id for cheap RLS.
-- =============================================================================

create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------
create type org_role as enum ('owner', 'admin', 'member');
create type workspace_role as enum ('owner', 'admin', 'member');
create type invite_status as enum ('pending', 'accepted', 'revoked', 'expired');
create type analytics_event_type as enum (
  'page.created', 'page.updated', 'page.viewed', 'page.deleted',
  'workspace.created', 'member.joined'
);

-- ---------------------------------------------------------------------------
-- profiles — mirrors auth.users with public-safe fields.
-- Populated by trigger on auth.users insert.
-- ---------------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index profiles_email_idx on profiles (lower(email));

-- ---------------------------------------------------------------------------
-- orgs — top-level tenant
-- ---------------------------------------------------------------------------
create table orgs (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  created_by uuid not null references profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index orgs_created_by_idx on orgs (created_by);

-- ---------------------------------------------------------------------------
-- org_members
-- ---------------------------------------------------------------------------
create table org_members (
  org_id uuid not null references orgs(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  role org_role not null default 'member',
  created_at timestamptz not null default now(),
  primary key (org_id, user_id)
);

create index org_members_user_id_idx on org_members (user_id);

-- ---------------------------------------------------------------------------
-- workspaces — second-level tenant, lives under an org
-- ---------------------------------------------------------------------------
create table workspaces (
  id uuid primary key default uuid_generate_v4(),
  org_id uuid not null references orgs(id) on delete cascade,
  name text not null,
  slug text not null,
  icon text,
  created_by uuid not null references profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, slug)
);

create index workspaces_org_id_idx on workspaces (org_id);

-- ---------------------------------------------------------------------------
-- workspace_members — explicit; not every org member is in every workspace.
-- ---------------------------------------------------------------------------
create table workspace_members (
  workspace_id uuid not null references workspaces(id) on delete cascade,
  org_id uuid not null references orgs(id) on delete cascade, -- denormalized
  user_id uuid not null references profiles(id) on delete cascade,
  role workspace_role not null default 'member',
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create index workspace_members_user_id_idx on workspace_members (user_id);
create index workspace_members_org_id_idx on workspace_members (org_id);

-- ---------------------------------------------------------------------------
-- pages — the documents themselves.
-- Tree via parent_id. The actual document content lives in page_yjs_state
-- (binary Y.Doc state) and a denormalized text snapshot in `content_text`
-- for search.
-- ---------------------------------------------------------------------------
create table pages (
  id uuid primary key default uuid_generate_v4(),
  org_id uuid not null references orgs(id) on delete cascade,
  workspace_id uuid not null references workspaces(id) on delete cascade,
  parent_id uuid references pages(id) on delete cascade,
  title text not null default 'Untitled',
  icon text,
  content_text text not null default '', -- plaintext snapshot for search
  is_archived boolean not null default false,
  position double precision not null default 0, -- sibling ordering, fractional indexing
  created_by uuid not null references profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index pages_workspace_id_idx on pages (workspace_id);
create index pages_org_id_idx on pages (org_id);
create index pages_parent_id_idx on pages (parent_id);
create index pages_created_by_idx on pages (created_by);
-- Common access pattern: list children of a parent in a workspace, ordered.
create index pages_workspace_parent_position_idx
  on pages (workspace_id, parent_id, position)
  where is_archived = false;

-- ---------------------------------------------------------------------------
-- page_yjs_state — binary Y.Doc state, written by Hocuspocus.
-- One row per page. Hocuspocus's database extension upserts on document save.
-- ---------------------------------------------------------------------------
create table page_yjs_state (
  page_id uuid primary key references pages(id) on delete cascade,
  -- denormalized for RLS without joining pages
  org_id uuid not null references orgs(id) on delete cascade,
  workspace_id uuid not null references workspaces(id) on delete cascade,
  state bytea not null,
  updated_at timestamptz not null default now()
);

create index page_yjs_state_workspace_id_idx on page_yjs_state (workspace_id);

-- ---------------------------------------------------------------------------
-- invites — workspace-level. (Stub for this session; see SECURITY.md.)
-- ---------------------------------------------------------------------------
create table invites (
  id uuid primary key default uuid_generate_v4(),
  org_id uuid not null references orgs(id) on delete cascade,
  workspace_id uuid references workspaces(id) on delete cascade, -- null = org-level invite
  email text not null,
  role workspace_role not null default 'member',
  token text not null unique,
  status invite_status not null default 'pending',
  invited_by uuid not null references profiles(id) on delete restrict,
  expires_at timestamptz not null default (now() + interval '7 days'),
  created_at timestamptz not null default now()
);

create index invites_email_idx on invites (lower(email));
create index invites_workspace_id_idx on invites (workspace_id);
create index invites_status_idx on invites (status);

-- ---------------------------------------------------------------------------
-- analytics_events — append-only event log.
-- ---------------------------------------------------------------------------
create table analytics_events (
  id bigserial primary key,
  org_id uuid not null references orgs(id) on delete cascade,
  workspace_id uuid references workspaces(id) on delete cascade,
  page_id uuid references pages(id) on delete set null,
  user_id uuid references profiles(id) on delete set null,
  event_type analytics_event_type not null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index analytics_events_org_created_idx on analytics_events (org_id, created_at desc);
create index analytics_events_workspace_created_idx on analytics_events (workspace_id, created_at desc);
create index analytics_events_user_idx on analytics_events (user_id);
create index analytics_events_type_idx on analytics_events (event_type);

-- ---------------------------------------------------------------------------
-- updated_at trigger
-- ---------------------------------------------------------------------------
create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at before update on profiles
  for each row execute function set_updated_at();
create trigger orgs_set_updated_at before update on orgs
  for each row execute function set_updated_at();
create trigger workspaces_set_updated_at before update on workspaces
  for each row execute function set_updated_at();
create trigger pages_set_updated_at before update on pages
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------------
-- Auto-provision profile on auth.users insert
-- ---------------------------------------------------------------------------
create or replace function handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();
