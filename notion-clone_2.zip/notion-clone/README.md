# Notion Clone

A collaborative document workspace. Real-time multi-user editing, full-text
search, and per-workspace activity reporting.

## Stack

- **Next.js 15** (App Router, Server Actions, RSC) + TypeScript strict
- **Supabase** for Postgres, Auth, and RLS
- **Hocuspocus** as a separate Node service for Yjs CRDT sync
- **Tiptap** as the editor, with `@tiptap/extension-collaboration` and
  `@tiptap/extension-collaboration-cursor`
- **Tailwind CSS** + shadcn-compatible CSS variables
- **Recharts** for the reporting dashboard

## Three services, three deploy targets

```
┌──────────────┐        ┌──────────────┐        ┌──────────────┐
│  Next.js     │◀──────▶│   Supabase   │◀──────▶│  Hocuspocus  │
│  (Vercel)    │  HTTPS │  (Postgres,  │   PG   │  (Railway,   │
│              │        │   Auth, RLS) │        │   Fly, etc.) │
└──────┬───────┘        └──────────────┘        └──────┬───────┘
       │                                                ▲
       │              Browser opens WSS to              │
       └────────────────────────────────────────────────┘
                  Hocuspocus, with Supabase JWT
```

The browser holds the Supabase session and opens a WebSocket to Hocuspocus,
passing its access token. Hocuspocus validates the JWT against Supabase
**and** checks workspace membership before accepting the connection.

## Quick start

```bash
# 1. Install
pnpm install
cd hocuspocus && pnpm install && cd ..

# 2. Configure
cp .env.example .env.local
# Fill in Supabase URL + keys, generate HOCUSPOCUS_INTERNAL_SECRET, set DATABASE_URL.

# 3. Apply migrations to a Supabase project
supabase db push   # or run supabase/migrations/*.sql in order

# 4. Run all three services in three terminals
pnpm dev                                # Next.js on :3000
cd hocuspocus && pnpm dev               # Hocuspocus on :1234
# (Supabase is hosted or running via `supabase start`)
```

## What's in this build

- ✅ Auth: email/password sign-up + sign-in, session refresh middleware,
  protected route group, OAuth callback handler with open-redirect protection
- ✅ Tenancy: Orgs → Workspaces → Pages, three roles each (owner/admin/member),
  full RLS coverage with bootstrap policies for first-run org+workspace
- ✅ Editor: Tiptap + Yjs over Hocuspocus, presence and live cursors, debounced
  title save, plaintext extraction for search on every persistence
- ✅ Search: Postgres `tsvector` with English config, GIN index, ranked results
  with `ts_headline` snippets, debounced search UI
- ✅ Reporting: real queries against `analytics_events`, materialized view
  refresh, three charts (activity over time, top contributors, pages per
  workspace)
- ✅ **Observability: Datadog (traces/metrics/logs) + Sentry (errors), pino
  structured logging with redaction and trace-ID injection, request-ID
  propagation, health endpoints, four runbooks, dashboard JSON, and monitor
  definitions. See `docs/OBSERVABILITY.md`.**

## What's deliberately not in this build

See `docs/decisions/` for the architecture decisions and `docs/SECURITY.md`
for the explicit non-goals. The short list: no payments, no page-level ACLs
(workspace-level only), no production OAuth provider hookup, no email
delivery for invites, no production deploy config.

## Repository layout

```
src/
  app/                  # Next.js App Router routes
    (marketing)/        # public landing
    (auth)/             # login, signup, OAuth callback
    (app)/              # protected app shell (sidebar layout)
      dashboard/        # home + first-run bootstrap
      w/[workspaceId]/  # workspace shell + page editor
      search/           # search UI
      reporting/        # analytics dashboard
    api/search/         # full-text search route
  features/             # feature folders, each owns its server actions + UI
    auth/  workspaces/  pages/  editor/  search/  reporting/
  lib/
    supabase/           # browser, server, middleware clients
    db/types.ts         # generated/maintained DB types
    utils/              # pure helpers (slugify, fractionalPosition, cn)
  middleware.ts         # auth gate

hocuspocus/             # Yjs sync server (separate service)
  src/index.ts          # Hocuspocus + Supabase JWT auth + Postgres persistence
  src/document-name.ts  # document-name parser (security-critical, tested)
  Dockerfile

supabase/migrations/
  0001_init.sql         # core schema, enums, triggers
  0002_rls.sql          # RLS + SECURITY DEFINER membership helpers
  0003_search.sql       # tsvector, search RPC, analytics, materialized view

tests/unit/             # Vitest, pure-logic tests
docs/                   # architecture.md, schema.md, decisions/*, SECURITY.md
```

## Test

```bash
pnpm test
```

Three test files. They cover pure logic where bugs are likely and
correctness matters: utility helpers, the security-critical document-name
parser, and the timezone-sensitive activity bucketer. Integration tests
against Supabase RLS are out of scope — see `docs/SECURITY.md`.

## Type-check

```bash
pnpm typecheck
```
