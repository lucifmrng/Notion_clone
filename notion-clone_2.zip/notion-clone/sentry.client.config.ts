import * as Sentry from "@sentry/nextjs";

/**
 * Browser-side Sentry. Captures unhandled errors and rejected promises in
 * client components.
 *
 * Same philosophy as the server: errors only, no traces (Datadog RUM
 * handles that if you enable it later).
 */
Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  environment: process.env.NEXT_PUBLIC_SENTRY_ENV ?? "development",
  release: process.env.NEXT_PUBLIC_SENTRY_RELEASE,

  tracesSampleRate: 0,
  replaysSessionSampleRate: 0,
  replaysOnErrorSampleRate: 0,

  // Don't capture cookies, localStorage, or session data.
  sendDefaultPii: false,

  beforeSend(event) {
    if (event.user?.email) event.user.email = "[REDACTED]";
    return event;
  },

  ignoreErrors: [
    // Browser noise — not actionable, would dominate the dashboard.
    "ResizeObserver loop limit exceeded",
    "ResizeObserver loop completed with undelivered notifications",
    "Non-Error promise rejection captured",
    // Editor-specific: WebSocket reconnects throw on tab backgrounding.
    "WebSocket connection failed",
  ],
});
