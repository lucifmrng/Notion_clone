import type { NextConfig } from "next";
import { withSentryConfig } from "@sentry/nextjs";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  experimental: {
    typedRoutes: true,
    // Required for instrumentation.ts to run on the Node runtime.
    instrumentationHook: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "*.supabase.co",
      },
    ],
  },
};

/**
 * Sentry's Next.js integration. We wrap the config to:
 *   - Upload source maps at build time (so stack traces in Sentry are readable)
 *   - Tunnel error events through a same-origin route (defeats ad blockers)
 *   - Suppress source map exposure to the public bundle
 *
 * These options are no-ops if SENTRY_AUTH_TOKEN isn't set, so dev builds
 * don't break.
 */
export default withSentryConfig(nextConfig, {
  org: process.env.SENTRY_ORG,
  project: process.env.SENTRY_PROJECT,
  authToken: process.env.SENTRY_AUTH_TOKEN,

  // Only print logs for uploading source maps in CI.
  silent: !process.env.CI,

  // Hide source maps from the public bundle.
  hideSourceMaps: true,

  // Tunnel events through this app to bypass ad blockers.
  tunnelRoute: "/monitoring",

  // Disable Sentry CLI logs except in CI.
  telemetry: false,

  // Auto-instrument React Server Components.
  reactComponentAnnotation: { enabled: true },
});
