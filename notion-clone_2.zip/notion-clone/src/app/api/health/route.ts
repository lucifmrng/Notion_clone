import { NextResponse } from "next/server";
import { createServiceRoleClient } from "@/lib/supabase/server";

/**
 * Health check for load balancers and uptime monitors.
 *
 * Two modes:
 *   GET /api/health         — shallow. Returns 200 if the process is alive.
 *                             Intended for k8s liveness / LB target checks.
 *                             Sub-millisecond, no I/O.
 *
 *   GET /api/health?deep=1  — deep. Probes Postgres via Supabase. Use for
 *                             readiness checks. Slower; do not use for
 *                             high-frequency LB checks.
 */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const deep = url.searchParams.get("deep") === "1";

  if (!deep) {
    return NextResponse.json(
      {
        status: "ok",
        version: process.env.DD_VERSION ?? "unknown",
        timestamp: new Date().toISOString(),
      },
      {
        status: 200,
        // Disable caching: stale health checks are dangerous.
        headers: { "cache-control": "no-store" },
      },
    );
  }

  const checks: Record<string, "ok" | "fail"> = {};
  let overallStatus = 200;

  // Postgres reachability via Supabase.
  try {
    const supabase = createServiceRoleClient();
    const { error } = await supabase.from("orgs").select("id").limit(1);
    checks.postgres = error ? "fail" : "ok";
    if (error) overallStatus = 503;
  } catch {
    checks.postgres = "fail";
    overallStatus = 503;
  }

  return NextResponse.json(
    {
      status: overallStatus === 200 ? "ok" : "degraded",
      checks,
      version: process.env.DD_VERSION ?? "unknown",
      timestamp: new Date().toISOString(),
    },
    {
      status: overallStatus,
      headers: { "cache-control": "no-store" },
    },
  );
}
