import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { requestLogger } from "@/lib/observability/request-context";
import { metrics, timed } from "@/lib/observability/metrics";

const querySchema = z.object({
  q: z.string().min(1).max(200),
  workspaceId: z.string().uuid().optional(),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

export async function GET(request: Request) {
  const log = await requestLogger({ route: "GET /api/search" });
  const supabase = await createClient();

  // Require auth. RLS does the work, but the route should 401 cleanly.
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    metrics.increment("notion.search.request", 1, ["outcome:unauthorized"]);
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const url = new URL(request.url);
  const parsed = querySchema.safeParse({
    q: url.searchParams.get("q"),
    workspaceId: url.searchParams.get("workspaceId") ?? undefined,
    limit: url.searchParams.get("limit") ?? undefined,
  });
  if (!parsed.success) {
    metrics.increment("notion.search.request", 1, ["outcome:invalid"]);
    return NextResponse.json({ error: "invalid query" }, { status: 400 });
  }

  try {
    const { data, error } = await timed(
      "notion.search.query.duration_ms",
      [parsed.data.workspaceId ? "scope:workspace" : "scope:all"],
      async () => {
        return await supabase.rpc("search_pages", {
          p_query: parsed.data.q,
          p_workspace_id: parsed.data.workspaceId ?? undefined,
          p_limit: parsed.data.limit,
        });
      },
    );

    if (error) {
      log.error({ err: error.message }, "search rpc failed");
      metrics.increment("notion.search.request", 1, ["outcome:error"]);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    const resultCount = data?.length ?? 0;
    metrics.increment("notion.search.request", 1, ["outcome:success"]);
    metrics.histogram("notion.search.result_count", resultCount, []);
    log.info(
      { user_id: user.id, query_length: parsed.data.q.length, result_count: resultCount },
      "search completed",
    );

    return NextResponse.json({ results: data ?? [] });
  } catch (err) {
    log.error({ err }, "search handler failed");
    metrics.increment("notion.search.request", 1, ["outcome:error"]);
    return NextResponse.json({ error: "internal error" }, { status: 500 });
  }
}
