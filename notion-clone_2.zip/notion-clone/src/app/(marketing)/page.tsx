import Link from "next/link";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b">
        <div className="container flex h-14 items-center justify-between">
          <span className="font-semibold">Notion Clone</span>
          <nav className="flex items-center gap-4 text-sm">
            <Link href="/login" className="text-muted-foreground hover:text-foreground">
              Sign in
            </Link>
            <Link
              href="/signup"
              className="rounded-md bg-primary px-3 py-1.5 font-medium text-primary-foreground hover:bg-primary/90"
            >
              Get started
            </Link>
          </nav>
        </div>
      </header>
      <main className="container flex flex-1 items-center justify-center text-center">
        <div className="max-w-2xl space-y-6 py-20">
          <h1 className="text-5xl font-semibold tracking-tight">
            A collaborative workspace.
          </h1>
          <p className="text-lg text-muted-foreground">
            Real-time editing, multiplayer cursors, full-text search across your team.
          </p>
          <Link
            href="/signup"
            className="inline-block rounded-md bg-primary px-5 py-2.5 font-medium text-primary-foreground hover:bg-primary/90"
          >
            Get started — free
          </Link>
        </div>
      </main>
    </div>
  );
}
