import { Suspense } from "react";
import Link from "next/link";
import { LoginForm } from "@/features/auth/login-form";

export default function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string }>;
}) {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="space-y-1 text-center">
          <h1 className="text-2xl font-semibold">Sign in</h1>
          <p className="text-sm text-muted-foreground">
            Welcome back. Sign in to continue.
          </p>
        </div>
        <Suspense>
          <LoginForm searchParamsPromise={searchParams} />
        </Suspense>
        <p className="text-center text-sm text-muted-foreground">
          New here?{" "}
          <Link href="/signup" className="font-medium underline underline-offset-4">
            Create an account
          </Link>
        </p>
      </div>
    </div>
  );
}
