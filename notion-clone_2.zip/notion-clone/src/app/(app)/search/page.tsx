import { SearchInterface } from "@/features/search/search-interface";

export default function SearchPage() {
  return (
    <div className="mx-auto max-w-3xl px-8 py-12">
      <h1 className="text-2xl font-semibold">Search</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Full-text search across all pages you have access to.
      </p>
      <div className="mt-8">
        <SearchInterface />
      </div>
    </div>
  );
}
