import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { AppSidebar } from "@/features/workspaces/app-sidebar";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  await getCurrentUser();
  const supabase = await createClient();

  // Pull workspaces for the sidebar. RLS scopes this to the user's memberships.
  const { data: workspaces } = await supabase
    .from("workspaces")
    .select("id, name, org_id")
    .order("created_at", { ascending: true });

  // First-time users with no workspace go to /dashboard which renders the
  // bootstrap form. If they're hitting a /w/ route directly, redirect home.
  // (We don't redirect from this layout because /dashboard is part of it.)

  return (
    <div className="flex h-screen overflow-hidden">
      <AppSidebar workspaces={workspaces ?? []} />
      <main className="flex-1 overflow-y-auto">{children}</main>
    </div>
  );
}
