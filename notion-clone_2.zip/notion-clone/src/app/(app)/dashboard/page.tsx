import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { bootstrapFirstWorkspace } from "@/features/workspaces/actions";

export default async function DashboardPage() {
  const user = await getCurrentUser();
  const supabase = await createClient();

  const { data: workspaces } = await supabase
    .from("workspaces")
    .select("id, name, org_id, orgs!inner(name)")
    .order("created_at", { ascending: true });

  const { data: recentPages } = await supabase
    .from("pages")
    .select("id, title, workspace_id, updated_at")
    .eq("is_archived", false)
    .order("updated_at", { ascending: false })
    .limit(8);

  const isFirstRun = !workspaces || workspaces.length === 0;

  if (isFirstRun) {
    return (
      <div className="mx-auto flex min-h-full max-w-md flex-col justify-center px-6 py-16">
        <h1 className="text-2xl font-semibold">Welcome.</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Let&apos;s set up your first workspace.
        </p>
        <form action={bootstrapFirstWorkspace} className="mt-8 space-y-4">
          <div className="space-y-1">
            <label className="text-sm font-medium" htmlFor="orgName">
              Organization name
            </label>
            <input
              id="orgName"
              name="orgName"
              required
              maxLength={80}
              defaultValue={`${user.email?.split("@")[0] ?? "My"}'s Org`}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div className="space-y-1">
            <label className="text-sm font-medium" htmlFor="workspaceName">
              First workspace name
            </label>
            <input
              id="workspaceName"
              name="workspaceName"
              required
              maxLength={80}
              defaultValue="Workspace"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            Create
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="text-2xl font-semibold">Home</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Pick up where you left off.
      </p>

      <section className="mt-8">
        <h2 className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
          Recent
        </h2>
        {recentPages && recentPages.length > 0 ? (
          <ul className="mt-3 divide-y rounded-md border">
            {recentPages.map((p) => (
              <li key={p.id}>
                <Link
                  href={`/w/${p.workspace_id}/p/${p.id}`}
                  className="flex items-center justify-between px-4 py-3 hover:bg-accent/50"
                >
                  <span className="truncate text-sm">{p.title || "Untitled"}</span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(p.updated_at).toLocaleDateString()}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-3 text-sm text-muted-foreground">
            No pages yet.{" "}
            <Link className="underline" href={`/w/${workspaces[0]!.id}`}>
              Open a workspace
            </Link>{" "}
            to create one.
          </p>
        )}
      </section>
    </div>
  );
}
