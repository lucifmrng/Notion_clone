import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { Editor } from "@/features/editor/editor";

export default async function PageRoute({
  params,
}: {
  params: Promise<{ workspaceId: string; pageId: string }>;
}) {
  const user = await getCurrentUser();
  const { workspaceId, pageId } = await params;
  const supabase = await createClient();

  const { data: page } = await supabase
    .from("pages")
    .select("id, workspace_id, title, icon, updated_at")
    .eq("id", pageId)
    .eq("workspace_id", workspaceId)
    .maybeSingle();

  if (!page) notFound();

  // Pull a fresh access token to hand to Hocuspocus. The provider sends it
  // on connect; Hocuspocus validates it via Supabase before allowing in.
  const { data: sessionData } = await supabase.auth.getSession();
  const token = sessionData.session?.access_token ?? null;

  // Display name for the cursor label
  const { data: profile } = await supabase
    .from("profiles")
    .select("display_name, email")
    .eq("id", user.id)
    .single();

  const displayName = profile?.display_name || profile?.email || "User";

  return (
    <Editor
      pageId={page.id}
      workspaceId={page.workspace_id}
      initialTitle={page.title}
      userId={user.id}
      displayName={displayName}
      token={token}
    />
  );
}
