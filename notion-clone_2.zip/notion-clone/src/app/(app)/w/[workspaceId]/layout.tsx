import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { listWorkspacePages } from "@/features/pages/actions";
import { WorkspacePageTree } from "@/features/pages/page-tree";

export default async function WorkspaceLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ workspaceId: string }>;
}) {
  await getCurrentUser();
  const { workspaceId } = await params;
  const supabase = await createClient();

  // Single query: if RLS denies us, this returns null and we 404.
  // No need for a separate is_workspace_member call — RLS *is* the check.
  const { data: workspace } = await supabase
    .from("workspaces")
    .select("id, name, org_id")
    .eq("id", workspaceId)
    .maybeSingle();
  if (!workspace) notFound();

  const pages = await listWorkspacePages(workspaceId);

  return (
    <div className="flex h-full">
      <div className="flex w-64 shrink-0 flex-col border-r bg-muted/20">
        <div className="border-b px-4 py-3">
          <h2 className="truncate text-sm font-semibold">{workspace.name}</h2>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          <WorkspacePageTree workspaceId={workspaceId} initialPages={pages} />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">{children}</div>
    </div>
  );
}
