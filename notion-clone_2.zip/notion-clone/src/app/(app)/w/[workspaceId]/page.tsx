import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { CreatePageButton } from "@/features/pages/create-page-button";

export default async function WorkspaceHome({
  params,
}: {
  params: Promise<{ workspaceId: string }>;
}) {
  await getCurrentUser();
  const { workspaceId } = await params;
  const supabase = await createClient();

  const { data: pages } = await supabase
    .from("pages")
    .select("id, title, updated_at, created_by")
    .eq("workspace_id", workspaceId)
    .eq("is_archived", false)
    .order("updated_at", { ascending: false })
    .limit(20);

  return (
    <div className="mx-auto max-w-3xl px-8 py-12">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Workspace</h1>
        <CreatePageButton workspaceId={workspaceId} />
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Recent pages in this workspace.
      </p>

      {pages && pages.length > 0 ? (
        <ul className="mt-8 divide-y rounded-md border">
          {pages.map((p) => (
            <li key={p.id}>
              <Link
                href={`/w/${workspaceId}/p/${p.id}`}
                className="flex items-center justify-between px-4 py-3 hover:bg-accent/50"
              >
                <span className="truncate text-sm">{p.title || "Untitled"}</span>
                <span className="text-xs text-muted-foreground">
                  {new Date(p.updated_at).toLocaleDateString()}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-12 rounded-lg border border-dashed py-12 text-center">
          <p className="text-sm text-muted-foreground">No pages yet.</p>
          <div className="mt-4">
            <CreatePageButton workspaceId={workspaceId} />
          </div>
        </div>
      )}
    </div>
  );
}
