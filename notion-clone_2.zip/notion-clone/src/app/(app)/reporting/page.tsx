import {
  getDailyActivity,
  getTopContributors,
  getPageCountsByWorkspace,
} from "@/features/reporting/queries";
import { ReportingDashboard } from "@/features/reporting/dashboard";

export default async function ReportingPage() {
  // Fetch in parallel — three independent queries.
  const [activity, contributors, pageCounts] = await Promise.all([
    getDailyActivity(),
    getTopContributors(),
    getPageCountsByWorkspace(),
  ]);

  return (
    <div className="mx-auto max-w-6xl px-8 py-12">
      <ReportingDashboard
        activity={activity}
        contributors={contributors}
        pageCounts={pageCounts}
      />
    </div>
  );
}
