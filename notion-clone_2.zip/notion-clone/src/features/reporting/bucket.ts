export interface DailyActivityPoint {
  day: string;          // ISO date (YYYY-MM-DD, UTC)
  pages_created: number;
  pages_updated: number;
}

interface RawEvent {
  created_at: string;
  event_type: string;
}

/**
 * Bucket raw analytics events into per-day counts, filling missing days
 * with zeros so the chart x-axis is contiguous.
 *
 * `since` and `until` define the inclusive day range (UTC). The output is
 * sorted ascending. We slice ISO strings rather than constructing Date
 * objects per row — `2025-04-15T...` always begins with the UTC date.
 */
export function bucketDailyActivity(
  events: RawEvent[],
  since: Date,
  until: Date,
): DailyActivityPoint[] {
  const buckets = new Map<string, { created: number; updated: number }>();

  for (const ev of events) {
    if (typeof ev.created_at !== "string" || ev.created_at.length < 10) continue;
    const day = ev.created_at.slice(0, 10);
    const b = buckets.get(day) ?? { created: 0, updated: 0 };
    if (ev.event_type === "page.created") b.created++;
    else if (ev.event_type === "page.updated") b.updated++;
    buckets.set(day, b);
  }

  const result: DailyActivityPoint[] = [];
  // Walk day-by-day in UTC. Use Date.UTC to avoid local-timezone drift around DST.
  const cursor = new Date(
    Date.UTC(since.getUTCFullYear(), since.getUTCMonth(), since.getUTCDate()),
  );
  const end = new Date(
    Date.UTC(until.getUTCFullYear(), until.getUTCMonth(), until.getUTCDate()),
  );
  while (cursor.getTime() <= end.getTime()) {
    const key = cursor.toISOString().slice(0, 10);
    const b = buckets.get(key) ?? { created: 0, updated: 0 };
    result.push({ day: key, pages_created: b.created, pages_updated: b.updated });
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return result;
}
