"use client";

import { useTransition } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { RefreshCw } from "lucide-react";
import { refreshAggregates } from "@/features/reporting/queries";
import type {
  DailyActivityPoint,
  TopContributor,
  WorkspacePageCount,
} from "@/features/reporting/queries";

export function ReportingDashboard({
  activity,
  contributors,
  pageCounts,
}: {
  activity: DailyActivityPoint[];
  contributors: TopContributor[];
  pageCounts: WorkspacePageCount[];
}) {
  const [refreshing, startRefresh] = useTransition();

  // Totals for the headline numbers.
  const totalCreated = activity.reduce((s, d) => s + d.pages_created, 0);
  const totalUpdated = activity.reduce((s, d) => s + d.pages_updated, 0);
  const totalPages = pageCounts.reduce((s, w) => s + w.page_count, 0);

  return (
    <>
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Reporting</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Activity across all workspaces you have access to. Last 30 days.
          </p>
        </div>
        <button
          type="button"
          onClick={() =>
            startRefresh(async () => {
              await refreshAggregates();
              // Server components refetch on next navigation; for an in-place
              // refresh you'd add router.refresh() here.
            })
          }
          disabled={refreshing}
          className="inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm hover:bg-accent disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh aggregates"}
        </button>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Stat label="Pages created (30d)" value={totalCreated} />
        <Stat label="Page updates (30d)" value={totalUpdated} />
        <Stat label="Total pages" value={totalPages} />
      </div>

      <section className="mt-8 rounded-lg border p-6">
        <h2 className="text-sm font-semibold">Activity over time</h2>
        <p className="text-xs text-muted-foreground">Pages created and updated, by day.</p>
        <div className="mt-4 h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={activity} margin={{ top: 5, right: 8, bottom: 5, left: -16 }}>
              <defs>
                <linearGradient id="created" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(142 71% 45%)" stopOpacity={0.6} />
                  <stop offset="95%" stopColor="hsl(142 71% 45%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="updated" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217 91% 60%)" stopOpacity={0.6} />
                  <stop offset="95%" stopColor="hsl(217 91% 60%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis
                dataKey="day"
                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                tickFormatter={(d: string) => d.slice(5)} // MM-DD
              />
              <YAxis
                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  background: "hsl(var(--background))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: 6,
                  fontSize: 12,
                }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Area
                type="monotone"
                dataKey="pages_created"
                name="Created"
                stroke="hsl(142 71% 45%)"
                fill="url(#created)"
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="pages_updated"
                name="Updated"
                stroke="hsl(217 91% 60%)"
                fill="url(#updated)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <section className="rounded-lg border p-6">
          <h2 className="text-sm font-semibold">Top contributors</h2>
          <p className="text-xs text-muted-foreground">Last 30 days.</p>
          {contributors.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">No activity yet.</p>
          ) : (
            <ul className="mt-4 divide-y">
              {contributors.map((c) => (
                <li key={c.user_id} className="flex items-center justify-between py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">
                      {c.display_name || c.email}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">
                      {c.pages_created} created · {c.pages_updated} updated
                    </p>
                  </div>
                  <span className="rounded bg-muted px-2 py-0.5 text-xs font-medium tabular-nums">
                    {c.total_events}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-lg border p-6">
          <h2 className="text-sm font-semibold">Pages per workspace</h2>
          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={pageCounts}
                layout="vertical"
                margin={{ top: 5, right: 8, bottom: 5, left: 8 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  type="number"
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  allowDecimals={false}
                />
                <YAxis
                  type="category"
                  dataKey="workspace_name"
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  width={120}
                />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--background))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 6,
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="page_count" name="Pages" fill="hsl(217 91% 60%)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>
    </>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg border p-4">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums">{value.toLocaleString()}</p>
    </div>
  );
}
