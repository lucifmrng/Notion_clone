"use server";

import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { bucketDailyActivity, type DailyActivityPoint } from "./bucket";

export type { DailyActivityPoint };

export interface TopContributor {
  user_id: string;
  display_name: string | null;
  email: string;
  pages_created: number;
  pages_updated: number;
  total_events: number;
}

export interface WorkspacePageCount {
  workspace_id: string;
  workspace_name: string;
  page_count: number;
}

/**
 * Daily activity over the last 30 days, scoped to workspaces the caller can see.
 * Reads the materialized view; refresh is on the user via refreshAggregates().
 */
export async function getDailyActivity(workspaceId?: string): Promise<DailyActivityPoint[]> {
  await getCurrentUser();
  const supabase = await createClient();

  const since = new Date();
  since.setDate(since.getDate() - 30);

  let q = supabase
    .from("analytics_events")
    .select("created_at, event_type")
    .gte("created_at", since.toISOString())
    .in("event_type", ["page.created", "page.updated"])
    .order("created_at", { ascending: true });

  if (workspaceId) q = q.eq("workspace_id", workspaceId);

  const { data, error } = await q;
  if (error) throw new Error(error.message);

  const until = new Date();
  return bucketDailyActivity(data ?? [], since, until);
}

export async function getTopContributors(workspaceId?: string): Promise<TopContributor[]> {
  await getCurrentUser();
  const supabase = await createClient();

  let q = supabase
    .from("v_top_contributors_30d")
    .select("user_id, display_name, email, pages_created, pages_updated, total_events");
  if (workspaceId) q = q.eq("workspace_id", workspaceId);

  const { data, error } = await q;
  if (error) throw new Error(error.message);

  // Sort + cap. The view doesn't sort or limit (RLS-friendly).
  return (data ?? [])
    .sort((a, b) => b.total_events - a.total_events)
    .slice(0, 10);
}

export async function getPageCountsByWorkspace(): Promise<WorkspacePageCount[]> {
  await getCurrentUser();
  const supabase = await createClient();

  const { data: workspaces, error: wsErr } = await supabase
    .from("workspaces")
    .select("id, name");
  if (wsErr) throw new Error(wsErr.message);

  if (!workspaces || workspaces.length === 0) return [];

  // Issue counts per workspace. With ~few workspaces this is fine; for
  // many, push to a SQL view. RLS scopes counts to visible pages.
  const counts = await Promise.all(
    workspaces.map(async (w) => {
      const { count } = await supabase
        .from("pages")
        .select("id", { count: "exact", head: true })
        .eq("workspace_id", w.id)
        .eq("is_archived", false);
      return {
        workspace_id: w.id,
        workspace_name: w.name,
        page_count: count ?? 0,
      };
    }),
  );

  return counts.sort((a, b) => b.page_count - a.page_count);
}

export async function refreshAggregates() {
  await getCurrentUser();
  const supabase = await createClient();
  const { error } = await supabase.rpc("refresh_reporting_aggregates");
  if (error) throw new Error(error.message);
}
