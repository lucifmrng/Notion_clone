"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { fractionalPosition } from "@/lib/utils";

const createPageSchema = z.object({
  workspaceId: z.string().uuid(),
  parentId: z.string().uuid().optional().nullable(),
  title: z.string().max(200).optional(),
});

export async function createPage(input: {
  workspaceId: string;
  parentId?: string | null;
  title?: string;
}) {
  const user = await getCurrentUser();
  const parsed = createPageSchema.safeParse(input);
  if (!parsed.success) throw new Error("Invalid input.");

  const supabase = await createClient();

  // Look up the workspace's org_id (RLS-safe — we're a member if we can read it).
  const { data: ws, error: wsErr } = await supabase
    .from("workspaces")
    .select("id, org_id")
    .eq("id", parsed.data.workspaceId)
    .single();
  if (wsErr || !ws) throw new Error("Workspace not found or no access.");

  // Find next position under parent.
  const { data: siblings } = await supabase
    .from("pages")
    .select("position")
    .eq("workspace_id", ws.id)
    .is("parent_id", parsed.data.parentId ?? null)
    .order("position", { ascending: false })
    .limit(1);
  const lastPos = siblings && siblings.length > 0 ? siblings[0]!.position : null;
  const position = fractionalPosition(lastPos, null);

  const { data: page, error } = await supabase
    .from("pages")
    .insert({
      org_id: ws.org_id,
      workspace_id: ws.id,
      parent_id: parsed.data.parentId ?? null,
      title: parsed.data.title ?? "Untitled",
      created_by: user.id,
      position,
    })
    .select("id")
    .single();
  if (error || !page) throw new Error(error?.message ?? "Page create failed.");

  revalidatePath(`/w/${ws.id}`, "layout");
  return { id: page.id };
}

export async function archivePage(pageId: string) {
  await getCurrentUser();
  const supabase = await createClient();
  const { error } = await supabase
    .from("pages")
    .update({ is_archived: true })
    .eq("id", pageId);
  if (error) throw new Error(error.message);
  revalidatePath("/", "layout");
}

const renameSchema = z.object({
  pageId: z.string().uuid(),
  title: z.string().min(1).max(200),
});

export async function renamePage(pageId: string, title: string) {
  await getCurrentUser();
  const parsed = renameSchema.safeParse({ pageId, title });
  if (!parsed.success) throw new Error("Invalid input.");

  const supabase = await createClient();
  const { error } = await supabase
    .from("pages")
    .update({ title: parsed.data.title })
    .eq("id", parsed.data.pageId);
  if (error) throw new Error(error.message);
  revalidatePath("/", "layout");
}

export async function createPageAndOpen(workspaceId: string) {
  const { id } = await createPage({ workspaceId });
  redirect(`/w/${workspaceId}/p/${id}`);
}

// ---------------------------------------------------------------------------
// Tree fetcher — used by the sidebar. Returns a flat list ordered by
// (parent_id, position); the client builds the tree.
// ---------------------------------------------------------------------------
export async function listWorkspacePages(workspaceId: string) {
  await getCurrentUser();
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("pages")
    .select("id, parent_id, title, icon, position, updated_at")
    .eq("workspace_id", workspaceId)
    .eq("is_archived", false)
    .order("position", { ascending: true });
  if (error) throw new Error(error.message);
  return data ?? [];
}
