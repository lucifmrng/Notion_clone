"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus } from "lucide-react";
import { createPage } from "@/features/pages/actions";

export function CreatePageButton({ workspaceId }: { workspaceId: string }) {
  const [pending, start] = useTransition();
  const router = useRouter();

  return (
    <button
      type="button"
      disabled={pending}
      onClick={() =>
        start(async () => {
          const { id } = await createPage({ workspaceId });
          router.push(`/w/${workspaceId}/p/${id}`);
          router.refresh();
        })
      }
      className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
    >
      <Plus className="h-4 w-4" />
      {pending ? "Creating…" : "New page"}
    </button>
  );
}
