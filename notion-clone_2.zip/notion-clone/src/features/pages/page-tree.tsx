"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useMemo, useTransition } from "react";
import { ChevronRight, FileText, Plus } from "lucide-react";
import { createPage } from "@/features/pages/actions";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";

interface PageNode {
  id: string;
  parent_id: string | null;
  title: string;
  icon: string | null;
  position: number;
  updated_at: string;
}

interface TreeNode extends PageNode {
  children: TreeNode[];
}

function buildTree(pages: PageNode[]): TreeNode[] {
  const map = new Map<string, TreeNode>();
  pages.forEach((p) => map.set(p.id, { ...p, children: [] }));
  const roots: TreeNode[] = [];
  for (const node of map.values()) {
    if (node.parent_id && map.has(node.parent_id)) {
      map.get(node.parent_id)!.children.push(node);
    } else {
      roots.push(node);
    }
  }
  // Children already arrive ordered by position from server.
  return roots;
}

export function WorkspacePageTree({
  workspaceId,
  initialPages,
}: {
  workspaceId: string;
  initialPages: PageNode[];
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const tree = useMemo(() => buildTree(initialPages), [initialPages]);
  const params = useParams<{ pageId?: string }>();
  const activePageId = params?.pageId;

  const handleCreate = (parentId: string | null) => {
    start(async () => {
      const { id } = await createPage({ workspaceId, parentId });
      router.push(`/w/${workspaceId}/p/${id}`);
      router.refresh();
    });
  };

  return (
    <div className="space-y-0.5">
      <div className="flex items-center justify-between px-2 py-1">
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Pages
        </span>
        <button
          type="button"
          onClick={() => handleCreate(null)}
          disabled={pending}
          className="rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground disabled:opacity-50"
          aria-label="New page"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>

      {tree.length === 0 && (
        <button
          type="button"
          onClick={() => handleCreate(null)}
          className="block w-full rounded-md px-2 py-1.5 text-left text-sm text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          + Create your first page
        </button>
      )}

      {tree.map((node) => (
        <TreeRow
          key={node.id}
          node={node}
          depth={0}
          workspaceId={workspaceId}
          activePageId={activePageId}
          onCreateChild={handleCreate}
        />
      ))}
    </div>
  );
}

function TreeRow({
  node,
  depth,
  workspaceId,
  activePageId,
  onCreateChild,
}: {
  node: TreeNode;
  depth: number;
  workspaceId: string;
  activePageId: string | undefined;
  onCreateChild: (parentId: string) => void;
}) {
  const active = activePageId === node.id;
  return (
    <div>
      <div
        className={cn(
          "group flex items-center gap-1 rounded-md px-2 py-1 text-sm",
          active
            ? "bg-accent text-accent-foreground"
            : "text-muted-foreground hover:bg-accent/50 hover:text-foreground",
        )}
        style={{ paddingLeft: `${0.5 + depth * 0.75}rem` }}
      >
        {node.children.length > 0 ? (
          <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />
        ) : (
          <FileText className="h-3.5 w-3.5 shrink-0 opacity-60" />
        )}
        <Link
          href={`/w/${workspaceId}/p/${node.id}`}
          className="flex-1 truncate"
        >
          {node.title || "Untitled"}
        </Link>
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault();
            onCreateChild(node.id);
          }}
          className="invisible rounded p-0.5 hover:bg-accent group-hover:visible"
          aria-label="New child page"
        >
          <Plus className="h-3 w-3" />
        </button>
      </div>
      {node.children.map((child) => (
        <TreeRow
          key={child.id}
          node={child}
          depth={depth + 1}
          workspaceId={workspaceId}
          activePageId={activePageId}
          onCreateChild={onCreateChild}
        />
      ))}
    </div>
  );
}
