"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Search as SearchIcon } from "lucide-react";

interface SearchResult {
  id: string;
  workspace_id: string;
  title: string;
  snippet: string;
  rank: number;
  updated_at: string;
}

export function SearchInterface() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([]);
      return;
    }

    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(
          `/api/search?q=${encodeURIComponent(query)}&limit=20`,
          { signal: controller.signal },
        );
        if (!res.ok) throw new Error(`Search failed (${res.status})`);
        const data = (await res.json()) as { results: SearchResult[] };
        setResults(data.results);
      } catch (e) {
        if ((e as Error).name === "AbortError") return;
        setError((e as Error).message);
      } finally {
        setLoading(false);
      }
    }, 250);

    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, [query]);

  return (
    <div className="space-y-4">
      <div className="relative">
        <SearchIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="search"
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search pages…"
          className="w-full rounded-md border border-input bg-background py-2.5 pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      {loading && <p className="text-sm text-muted-foreground">Searching…</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}

      {!loading && query.trim().length >= 2 && results.length === 0 && (
        <p className="text-sm text-muted-foreground">
          No results for &ldquo;{query}&rdquo;.
        </p>
      )}

      <ul className="space-y-2">
        {results.map((r) => (
          <li key={r.id}>
            <Link
              href={`/w/${r.workspace_id}/p/${r.id}`}
              className="block rounded-md border p-3 transition hover:bg-accent/50"
            >
              <h3 className="text-sm font-medium">{r.title || "Untitled"}</h3>
              {r.snippet && (
                <p
                  className="mt-1 text-xs text-muted-foreground"
                  // ts_headline returns HTML <b> tags around hits — safe (server-generated)
                  dangerouslySetInnerHTML={{ __html: r.snippet }}
                />
              )}
              <span className="mt-1 block text-[10px] uppercase tracking-wide text-muted-foreground/70">
                Updated {new Date(r.updated_at).toLocaleDateString()}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
