"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/features/auth/server";
import { slugify } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Bootstrap: create the user's first org + workspace.
// Performed as three writes; we rely on the bootstrap RLS policies which
// permit the creator to insert themselves as owner when no members exist yet.
// ---------------------------------------------------------------------------
export async function bootstrapFirstWorkspace(formData: FormData) {
  const user = await getCurrentUser();
  const supabase = await createClient();

  const orgName = String(formData.get("orgName") || "").trim() || "My Org";
  const workspaceName =
    String(formData.get("workspaceName") || "").trim() || "Workspace";

  const orgSlug = `${slugify(orgName)}-${user.id.slice(0, 6)}`;
  const workspaceSlug = slugify(workspaceName);

  const { data: org, error: orgErr } = await supabase
    .from("orgs")
    .insert({ name: orgName, slug: orgSlug, created_by: user.id })
    .select("id")
    .single();

  if (orgErr || !org) throw new Error(`Org create failed: ${orgErr?.message}`);

  const { error: omErr } = await supabase.from("org_members").insert({
    org_id: org.id,
    user_id: user.id,
    role: "owner",
  });
  if (omErr) throw new Error(`Org membership create failed: ${omErr.message}`);

  const { data: ws, error: wsErr } = await supabase
    .from("workspaces")
    .insert({
      org_id: org.id,
      name: workspaceName,
      slug: workspaceSlug,
      created_by: user.id,
    })
    .select("id")
    .single();
  if (wsErr || !ws) throw new Error(`Workspace create failed: ${wsErr?.message}`);

  const { error: wmErr } = await supabase.from("workspace_members").insert({
    workspace_id: ws.id,
    org_id: org.id,
    user_id: user.id,
    role: "owner",
  });
  if (wmErr) throw new Error(`Workspace membership create failed: ${wmErr.message}`);

  revalidatePath("/", "layout");
  redirect(`/w/${ws.id}`);
}

// ---------------------------------------------------------------------------
// Create an additional workspace within an existing org.
// ---------------------------------------------------------------------------
const createWorkspaceSchema = z.object({
  orgId: z.string().uuid(),
  name: z.string().min(1).max(80),
});

export async function createWorkspace(formData: FormData) {
  const user = await getCurrentUser();
  const supabase = await createClient();

  const parsed = createWorkspaceSchema.safeParse({
    orgId: formData.get("orgId"),
    name: formData.get("name"),
  });
  if (!parsed.success) throw new Error("Invalid input.");

  const { data: ws, error } = await supabase
    .from("workspaces")
    .insert({
      org_id: parsed.data.orgId,
      name: parsed.data.name,
      slug: slugify(parsed.data.name),
      created_by: user.id,
    })
    .select("id")
    .single();
  if (error || !ws) throw new Error(error?.message ?? "Create failed");

  await supabase.from("workspace_members").insert({
    workspace_id: ws.id,
    org_id: parsed.data.orgId,
    user_id: user.id,
    role: "owner",
  });

  revalidatePath("/", "layout");
  redirect(`/w/${ws.id}`);
}

// ---------------------------------------------------------------------------
// Workspace + org listing for sidebar / switcher.
// ---------------------------------------------------------------------------
export async function listMyWorkspaces() {
  await getCurrentUser();
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("workspaces")
    .select("id, name, slug, icon, org_id, orgs!inner(name)")
    .order("created_at", { ascending: true });
  if (error) throw new Error(error.message);
  return data ?? [];
}
