"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, BarChart3, LogOut, Plus } from "lucide-react";
import { logoutAction } from "@/features/auth/actions";
import { cn } from "@/lib/utils";

interface Workspace {
  id: string;
  name: string;
  org_id: string;
}

export function AppSidebar({ workspaces }: { workspaces: Workspace[] }) {
  const pathname = usePathname();

  const nav = [
    { href: "/dashboard", label: "Home", icon: Home },
    { href: "/search", label: "Search", icon: Search },
    { href: "/reporting", label: "Reporting", icon: BarChart3 },
  ];

  return (
    <aside className="flex w-64 shrink-0 flex-col border-r bg-muted/30">
      <div className="border-b p-4">
        <span className="text-sm font-semibold">Notion Clone</span>
      </div>

      <nav className="flex flex-col gap-0.5 p-2">
        {nav.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(href + "/");
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-1.5 text-sm",
                active
                  ? "bg-accent text-accent-foreground"
                  : "text-muted-foreground hover:bg-accent/50 hover:text-foreground",
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="flex-1 overflow-y-auto px-2 pb-2">
        <div className="mt-2 flex items-center justify-between px-3 py-1">
          <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Workspaces
          </span>
          <Link
            href="/dashboard"
            className="rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="New workspace"
          >
            <Plus className="h-3.5 w-3.5" />
          </Link>
        </div>
        <ul className="space-y-0.5">
          {workspaces.map((w) => {
            const active = pathname.startsWith(`/w/${w.id}`);
            return (
              <li key={w.id}>
                <Link
                  href={`/w/${w.id}`}
                  className={cn(
                    "block truncate rounded-md px-3 py-1.5 text-sm",
                    active
                      ? "bg-accent text-accent-foreground"
                      : "text-muted-foreground hover:bg-accent/50 hover:text-foreground",
                  )}
                >
                  {w.name}
                </Link>
              </li>
            );
          })}
          {workspaces.length === 0 && (
            <li className="px-3 py-1.5 text-xs text-muted-foreground">
              No workspaces yet.
            </li>
          )}
        </ul>
      </div>

      <form action={logoutAction} className="border-t p-2">
        <button
          type="submit"
          className="flex w-full items-center gap-2 rounded-md px-3 py-1.5 text-sm text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </form>
    </aside>
  );
}
