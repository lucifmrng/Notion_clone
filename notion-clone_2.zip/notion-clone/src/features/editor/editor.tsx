"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import * as Y from "yjs";
import { HocuspocusProvider } from "@hocuspocus/provider";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Placeholder from "@tiptap/extension-placeholder";
import Collaboration from "@tiptap/extension-collaboration";
import CollaborationCursor from "@tiptap/extension-collaboration-cursor";
import { renamePage } from "@/features/pages/actions";

const CURSOR_COLORS = [
  "#ef4444", "#f97316", "#eab308", "#22c55e",
  "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899",
];

function pickColor(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return CURSOR_COLORS[Math.abs(hash) % CURSOR_COLORS.length]!;
}

export function Editor({
  pageId,
  workspaceId,
  initialTitle,
  userId,
  displayName,
  token,
}: {
  pageId: string;
  workspaceId: string;
  initialTitle: string;
  userId: string;
  displayName: string;
  token: string | null;
}) {
  const [title, setTitle] = useState(initialTitle);
  const [status, setStatus] = useState<"connecting" | "connected" | "disconnected">(
    "connecting",
  );
  const [peerCount, setPeerCount] = useState(0);
  const titleSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // One Y.Doc and one provider per mount. Both are torn down on unmount.
  const ydoc = useMemo(() => new Y.Doc(), [pageId]);

  const provider = useMemo(() => {
    const url = process.env.NEXT_PUBLIC_HOCUSPOCUS_URL;
    if (!url) {
      console.error("NEXT_PUBLIC_HOCUSPOCUS_URL is not set");
      return null;
    }
    return new HocuspocusProvider({
      url,
      // Document name encodes both workspace and page so the server can
      // authorize at workspace granularity.
      name: `${workspaceId}:${pageId}`,
      document: ydoc,
      token: token ?? "",
      onStatus: ({ status }) => {
        if (status === "connected") setStatus("connected");
        else if (status === "connecting") setStatus("connecting");
        else setStatus("disconnected");
      },
      onAwarenessUpdate: ({ states }) => {
        setPeerCount(states.length);
      },
    });
  }, [pageId, workspaceId, token, ydoc]);

  useEffect(() => {
    return () => {
      provider?.destroy();
      ydoc.destroy();
    };
  }, [provider, ydoc]);

  const editor = useEditor(
    {
      // Disable history extension; Yjs CRDT supplies its own (y-prosemirror).
      extensions: [
        StarterKit.configure({ history: false }),
        Placeholder.configure({ placeholder: "Type to start writing…" }),
        ...(provider
          ? [
              Collaboration.configure({ document: ydoc }),
              CollaborationCursor.configure({
                provider,
                user: {
                  name: displayName,
                  color: pickColor(userId),
                },
              }),
            ]
          : []),
      ],
      // Important: avoid SSR mismatch from collaboration extensions hydrating
      // an empty doc before the provider syncs.
      immediatelyRender: false,
    },
    [provider, ydoc],
  );

  const handleTitleChange = (next: string) => {
    setTitle(next);
    if (titleSaveTimer.current) clearTimeout(titleSaveTimer.current);
    titleSaveTimer.current = setTimeout(() => {
      renamePage(pageId, next.trim() || "Untitled").catch(console.error);
    }, 600);
  };

  return (
    <div className="mx-auto max-w-3xl px-12 pb-32 pt-16">
      <div className="mb-3 flex items-center justify-end gap-3 text-xs text-muted-foreground">
        <ConnectionStatus status={status} peers={peerCount} />
      </div>

      <input
        type="text"
        value={title}
        onChange={(e) => handleTitleChange(e.target.value)}
        placeholder="Untitled"
        className="w-full bg-transparent text-4xl font-bold tracking-tight outline-none placeholder:text-muted-foreground/40"
        maxLength={200}
      />

      <div className="mt-6">
        {editor ? (
          <EditorContent editor={editor} />
        ) : (
          <p className="text-sm text-muted-foreground">Loading editor…</p>
        )}
      </div>
    </div>
  );
}

function ConnectionStatus({
  status,
  peers,
}: {
  status: "connecting" | "connected" | "disconnected";
  peers: number;
}) {
  const colors = {
    connected: "bg-emerald-500",
    connecting: "bg-amber-500",
    disconnected: "bg-red-500",
  };
  const labels = {
    connected: peers > 1 ? `${peers} editing` : "Live",
    connecting: "Connecting…",
    disconnected: "Offline",
  };
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={`h-1.5 w-1.5 rounded-full ${colors[status]}`} />
      {labels[status]}
    </span>
  );
}
