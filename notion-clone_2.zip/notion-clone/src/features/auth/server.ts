import { redirect } from "next/navigation";
import { cache } from "react";
import { createClient } from "@/lib/supabase/server";

/**
 * RSC-cached fetch of the current authenticated user. Throws by redirecting
 * to /login if there's no session — so call this only in protected routes.
 *
 * Always uses getUser() (validates JWT), never getSession() (cookie-only).
 */
export const getCurrentUser = cache(async () => {
  const supabase = await createClient();
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    redirect("/login");
  }

  return user;
});

/**
 * Same as getCurrentUser but returns null instead of redirecting.
 * Use in layouts/components that render for both authed and anon users.
 */
export const getOptionalUser = cache(async () => {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user;
});
