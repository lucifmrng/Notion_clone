/**
 * Datadog tracer init. Must be the very first thing loaded in the process,
 * because dd-trace works by monkey-patching modules at require/import time.
 * Loading anything else before this means those modules don't get traced.
 *
 * Next.js's `instrumentation.ts` runs on server start before any request
 * handlers, which is the right hook. See: src/instrumentation.ts.
 *
 * What gets auto-instrumented:
 *   - http / https (every outbound and inbound request)
 *   - next (server-side rendering, route handlers, server actions)
 *   - pg (every Postgres query)
 *   - undici / fetch (Supabase HTTP calls)
 *   - pino (log injection of dd.trace_id and dd.span_id)
 *
 * We disable some plugins explicitly to keep noise down.
 */

export function initTracer() {
  // Skip entirely in dev unless explicitly enabled, to avoid agent connection
  // errors flooding the console for local dev with no Datadog agent.
  if (
    process.env.NODE_ENV !== "production" &&
    process.env.DD_TRACE_ENABLED !== "true"
  ) {
    return;
  }

  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const tracer = require("dd-trace");

  tracer.init({
    service: process.env.DD_SERVICE ?? "notion-clone-web",
    env: process.env.DD_ENV ?? "development",
    version: process.env.DD_VERSION ?? "0.1.0",

    // Sampling: 10% in prod by default. Override per route via
    // tracer.scope().active()?.setTag('manual.keep') for known-important paths
    // (e.g. signup, payment, errors).
    sampleRate: Number(process.env.DD_TRACE_SAMPLE_RATE ?? "0.1"),

    // Enable runtime metrics (heap, event-loop lag, GC). Goes to dogstatsd.
    runtimeMetrics: true,

    // Profiler: CPU and heap profiles. Adds overhead; enable in prod only
    // if you need it and you're on a paying plan.
    profiling: process.env.DD_PROFILING_ENABLED === "true",

    // Log injection: pino picks up the IDs via the mixin in logger.ts.
    // dd-trace also patches pino directly, but we set this for defense.
    logInjection: true,

    // Tags applied to every span/metric.
    tags: {
      "service.tier": "web",
    },
  });

  // Tune individual integrations.
  tracer.use("pg", {
    // Sanitize SQL: keep statement shape, drop literal values.
    service: "notion-clone-postgres",
  });
  tracer.use("next", {
    // Don't trace static asset paths.
    blocklist: ["/_next/static", "/favicon.ico"],
  });
  tracer.use("http", {
    // Don't trace health checks (would dominate the trace volume).
    blocklist: ["/api/health"],
  });
}
