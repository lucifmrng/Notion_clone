import { randomUUID } from "node:crypto";
import { headers } from "next/headers";
import { childLogger } from "./logger";
import type { Logger } from "pino";

const REQUEST_ID_HEADER = "x-request-id";

/**
 * Get or mint a request ID. Honors an upstream-provided header so traffic
 * from a load balancer or API gateway keeps its correlation ID.
 *
 * Call this from RSC, route handlers, and server actions. The middleware
 * is responsible for ensuring the header is present on the incoming
 * Request; this just reads it.
 */
export async function getRequestId(): Promise<string> {
  const h = await headers();
  return h.get(REQUEST_ID_HEADER) ?? randomUUID();
}

/**
 * Convenience: build a child logger pre-bound to the current request ID
 * and any extra context. Use this in route handlers and server actions
 * instead of the bare `logger`.
 *
 * Example:
 *   const log = await requestLogger({ user_id: user.id, route: "createPage" });
 *   log.info({ workspace_id }, "creating page");
 */
export async function requestLogger(
  bindings: Record<string, unknown> = {},
): Promise<Logger> {
  const requestId = await getRequestId();
  return childLogger({ request_id: requestId, ...bindings });
}

export { REQUEST_ID_HEADER };
