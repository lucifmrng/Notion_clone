/**
 * Custom application metrics. Wraps Datadog's dogstatsd client so callers
 * don't depend on the underlying transport.
 *
 * Naming convention: `notion.<domain>.<metric>` with snake_case.
 * Examples:
 *   notion.page.created               counter
 *   notion.search.query.duration_ms   histogram
 *   notion.editor.connected_peers     gauge
 *
 * Tags follow the Datadog convention (key:value), kept low-cardinality —
 * never tag with user_id or page_id directly, those would explode the
 * metric series count and cost. Use logs for high-cardinality fields.
 *
 * If dd-trace isn't running, all calls are no-ops. Code that records
 * metrics should never have to check whether tracing is enabled.
 */

interface MetricsClient {
  increment(name: string, value?: number, tags?: string[]): void;
  decrement(name: string, value?: number, tags?: string[]): void;
  gauge(name: string, value: number, tags?: string[]): void;
  histogram(name: string, value: number, tags?: string[]): void;
  distribution(name: string, value: number, tags?: string[]): void;
  timing(name: string, durationMs: number, tags?: string[]): void;
}

const noop: MetricsClient = {
  increment() {},
  decrement() {},
  gauge() {},
  histogram() {},
  distribution() {},
  timing() {},
};

function getClient(): MetricsClient {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const tracer = require("dd-trace");
    const dogstatsd = tracer?.dogstatsd;
    if (!dogstatsd) return noop;
    return {
      increment: dogstatsd.increment.bind(dogstatsd),
      decrement: dogstatsd.decrement.bind(dogstatsd),
      gauge: dogstatsd.gauge.bind(dogstatsd),
      histogram: dogstatsd.histogram.bind(dogstatsd),
      distribution: dogstatsd.distribution.bind(dogstatsd),
      timing: (name, ms, tags) => dogstatsd.histogram(name, ms, tags),
    };
  } catch {
    return noop;
  }
}

let cached: MetricsClient | null = null;

export const metrics: MetricsClient = new Proxy({} as MetricsClient, {
  get(_target, prop: keyof MetricsClient) {
    if (!cached) cached = getClient();
    return cached[prop];
  },
});

/**
 * Time an async function and emit a histogram of its duration.
 * Usage:
 *   const result = await timed("notion.search.query.duration_ms",
 *                              ["index:default"],
 *                              () => searchPages(...));
 */
export async function timed<T>(
  name: string,
  tags: string[],
  fn: () => Promise<T>,
): Promise<T> {
  const start = performance.now();
  try {
    const result = await fn();
    metrics.histogram(name, performance.now() - start, [...tags, "outcome:success"]);
    return result;
  } catch (err) {
    metrics.histogram(name, performance.now() - start, [...tags, "outcome:error"]);
    throw err;
  }
}
