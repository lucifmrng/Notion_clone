import * as Sentry from "@sentry/nextjs";

/**
 * Server-side Sentry. Captures unhandled exceptions in route handlers,
 * server actions, and React Server Components.
 *
 * Key choices:
 *   - tracesSampleRate is intentionally 0. Tracing is Datadog's job; Sentry
 *     is errors-only. This avoids paying twice for the same data.
 *   - We attach user context via beforeSend so Personally identifiable
 *     fields (email) are scrubbed before leaving the process. Sentry will
 *     still group errors by user_id, which is what we want for triage.
 */
export function initSentry() {
  if (!process.env.SENTRY_DSN) {
    // Sentry is optional in dev; stay silent.
    return;
  }

  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.SENTRY_ENV ?? process.env.NODE_ENV ?? "development",
    release: process.env.SENTRY_RELEASE ?? process.env.DD_VERSION,

    tracesSampleRate: 0,
    profilesSampleRate: 0,

    // We do NOT want full request bodies in error reports — the editor
    // sends document-content payloads. Keep only metadata.
    sendDefaultPii: false,

    beforeSend(event) {
      // Scrub email from user context if present.
      if (event.user?.email) {
        event.user.email = "[REDACTED]";
      }
      // Strip cookies and authorization headers from request data.
      if (event.request?.headers) {
        const h = event.request.headers as Record<string, string>;
        delete h.cookie;
        delete h.authorization;
        delete h.Cookie;
        delete h.Authorization;
      }
      return event;
    },

    // Don't report known-noise errors that aren't actionable.
    ignoreErrors: [
      "NEXT_REDIRECT", // Server actions throw this for redirects; not an error.
      "NEXT_NOT_FOUND", // Same.
      "AbortError", // Client navigations abort in-flight fetches.
    ],
  });
}
