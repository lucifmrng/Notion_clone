import pino, { type Logger, type LoggerOptions } from "pino";

/**
 * Structured logger.
 *
 * Three things happen here that matter:
 *
 *   1. In production we emit JSON to stdout. The Datadog Agent (or any
 *      log collector) tails stdout and forwards. Don't pipe to a file
 *      from the app — let the platform handle log shipping.
 *
 *   2. We redact a hard-coded list of sensitive paths. This is defense
 *      in depth, not the primary defense — the primary defense is not
 *      logging secrets in the first place. But code drifts; the redactor
 *      catches mistakes.
 *
 *   3. We inject Datadog trace IDs (`dd.trace_id`, `dd.span_id`) into
 *      every log line. Datadog's UI uses these to wire log entries into
 *      the trace view. If `dd-trace` isn't running, the fields are
 *      omitted gracefully.
 *
 * What we deliberately do NOT log:
 *   - Document content (Y.Doc state, plaintext snapshots)
 *   - Auth tokens, JWTs, service-role keys
 *   - Email bodies, password fields, OAuth state
 *   - Full request/response bodies (only metadata)
 */

const REDACT_PATHS = [
  // Common secret-ish keys, regardless of nesting
  "*.password",
  "*.token",
  "*.access_token",
  "*.refresh_token",
  "*.authorization",
  "*.api_key",
  "*.apiKey",
  "*.secret",
  // HTTP-specific
  'req.headers.authorization',
  'req.headers.cookie',
  'res.headers["set-cookie"]',
  // Supabase-specific
  "*.serviceRoleKey",
  "*.SUPABASE_SERVICE_ROLE_KEY",
];

const isProd = process.env.NODE_ENV === "production";

const base: LoggerOptions = {
  level: process.env.LOG_LEVEL ?? (isProd ? "info" : "debug"),
  redact: {
    paths: REDACT_PATHS,
    censor: "[REDACTED]",
  },
  // Datadog correlation. dd-trace patches `pino` to inject these fields,
  // but we also expose a manual mixin path for environments where the
  // patch hasn't run yet (e.g. tests).
  mixin() {
    try {
      // Lazy require to avoid loading dd-trace in unit tests.
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const tracer = require("dd-trace");
      const span = tracer?.scope?.()?.active?.();
      if (!span) return {};
      const ctx = span.context();
      return {
        "dd.trace_id": ctx.toTraceId(),
        "dd.span_id": ctx.toSpanId(),
        "dd.service": process.env.DD_SERVICE,
        "dd.env": process.env.DD_ENV,
        "dd.version": process.env.DD_VERSION,
      };
    } catch {
      return {};
    }
  },
  // Datadog expects `status` rather than `level` for the severity field.
  // We keep `level` for human readability and also emit `status`.
  formatters: {
    level(label) {
      return { level: label, status: label };
    },
  },
  base: {
    service: process.env.DD_SERVICE ?? "notion-clone-web",
    env: process.env.DD_ENV ?? process.env.NODE_ENV ?? "development",
    version: process.env.DD_VERSION ?? "0.1.0",
  },
};

const transport = !isProd
  ? {
      target: "pino-pretty",
      options: {
        colorize: true,
        translateTime: "SYS:HH:MM:ss.l",
        ignore: "pid,hostname,service,env,version,dd.trace_id,dd.span_id,dd.service,dd.env,dd.version",
      },
    }
  : undefined;

export const logger: Logger = pino({ ...base, transport });

/**
 * Per-request child logger. Carries request_id and any additional context.
 */
export function childLogger(bindings: Record<string, unknown>): Logger {
  return logger.child(bindings);
}
