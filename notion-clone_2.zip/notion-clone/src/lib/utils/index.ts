import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * URL-safe slug from a free-form name. Used for org/workspace slugs.
 * Not collision-safe — append a short random suffix on conflict at the call site.
 */
export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48) || "untitled";
}

/**
 * Fractional position between two siblings. Used for page reordering without
 * having to renumber the entire list. If both bounds are null, return 1024.
 */
export function fractionalPosition(
  before: number | null,
  after: number | null,
): number {
  if (before === null && after === null) return 1024;
  if (before === null) return after! / 2;
  if (after === null) return before + 1024;
  return (before + after) / 2;
}

export function assertEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}
