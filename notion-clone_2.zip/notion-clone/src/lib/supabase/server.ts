import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { Database } from "@/lib/db/types";

/**
 * Server-side Supabase client. Use in Server Components, Server Actions,
 * and Route Handlers. Reads/writes auth cookies.
 *
 * Note: in pure RSC the `setAll` call is a no-op because cookies can't be
 * mutated during render. That's expected — the middleware refresh path is
 * what keeps sessions alive. We swallow the throw rather than propagating.
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options),
            );
          } catch {
            // Called from a Server Component — ignore. Middleware handles refresh.
          }
        },
      },
    },
  );
}

/**
 * Service-role client for trusted server contexts (admin actions,
 * Hocuspocus auth endpoint). NEVER use in code that runs in response to
 * unauthenticated input without first validating the caller.
 */
export function createServiceRoleClient() {
  // Lazy import; this should not be bundled into client code.
  const { createClient } = require("@supabase/supabase-js") as typeof import("@supabase/supabase-js");
  return createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      auth: { persistSession: false, autoRefreshToken: false },
    },
  );
}
