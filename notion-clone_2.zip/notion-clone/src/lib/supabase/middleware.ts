import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { randomUUID } from "node:crypto";
import type { Database } from "@/lib/db/types";

const REQUEST_ID_HEADER = "x-request-id";

/**
 * Refreshes the Supabase session and gates the (app) route group.
 * Logic:
 *   - Always refresh the session (writes new cookies if needed).
 *   - If the user hits a protected path without a session → redirect to /login.
 *   - If the user hits /login or /signup with a session → redirect to /dashboard.
 *
 * Also mints/propagates a request ID. This runs on the edge runtime, so we
 * can't use pino here; we set the header and let downstream Node code log.
 */
export async function updateSession(request: NextRequest) {
  // Mint or honor the request ID before anything else.
  const requestId = request.headers.get(REQUEST_ID_HEADER) ?? randomUUID();

  // Carry the request ID forward on the request that downstream handlers see.
  const incomingHeaders = new Headers(request.headers);
  incomingHeaders.set(REQUEST_ID_HEADER, requestId);

  let response = NextResponse.next({
    request: { headers: incomingHeaders },
  });
  response.headers.set(REQUEST_ID_HEADER, requestId);

  // Skip auth + Supabase work for health checks and static-ish paths.
  // The matcher already filters _next/static, but health is its own path.
  const path = request.nextUrl.pathname;
  if (path === "/api/health") {
    return response;
  }

  const supabase = createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value),
          );
          response = NextResponse.next({
            request: { headers: incomingHeaders },
          });
          response.headers.set(REQUEST_ID_HEADER, requestId);
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options),
          );
        },
      },
    },
  );

  // IMPORTANT: getUser() validates the JWT against Supabase auth, unlike
  // getSession() which only reads the cookie. Always use getUser() in middleware.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const isAuthPath = path.startsWith("/login") || path.startsWith("/signup");
  const isProtectedPath =
    path.startsWith("/dashboard") ||
    path.startsWith("/w/") ||
    path.startsWith("/search") ||
    path.startsWith("/reporting");

  if (!user && isProtectedPath) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", path);
    return NextResponse.redirect(url);
  }

  if (user && isAuthPath) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return response;
}
