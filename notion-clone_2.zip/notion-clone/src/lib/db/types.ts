/**
 * Database types matching supabase/migrations/*.sql.
 *
 * In a real workflow, regenerate via `pnpm db:types` after every schema change.
 * Hand-maintained here because the build environment can't reach Supabase.
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type OrgRole = "owner" | "admin" | "member";
export type WorkspaceRole = "owner" | "admin" | "member";
export type InviteStatus = "pending" | "accepted" | "revoked" | "expired";
export type AnalyticsEventType =
  | "page.created"
  | "page.updated"
  | "page.viewed"
  | "page.deleted"
  | "workspace.created"
  | "member.joined";

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          display_name: string | null;
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          display_name?: string | null;
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Insert"]>;
      };
      orgs: {
        Row: {
          id: string;
          name: string;
          slug: string;
          created_by: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          created_by: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["orgs"]["Insert"]>;
      };
      org_members: {
        Row: {
          org_id: string;
          user_id: string;
          role: OrgRole;
          created_at: string;
        };
        Insert: {
          org_id: string;
          user_id: string;
          role?: OrgRole;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["org_members"]["Insert"]>;
      };
      workspaces: {
        Row: {
          id: string;
          org_id: string;
          name: string;
          slug: string;
          icon: string | null;
          created_by: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          org_id: string;
          name: string;
          slug: string;
          icon?: string | null;
          created_by: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["workspaces"]["Insert"]>;
      };
      workspace_members: {
        Row: {
          workspace_id: string;
          org_id: string;
          user_id: string;
          role: WorkspaceRole;
          created_at: string;
        };
        Insert: {
          workspace_id: string;
          org_id: string;
          user_id: string;
          role?: WorkspaceRole;
          created_at?: string;
        };
        Update: Partial<
          Database["public"]["Tables"]["workspace_members"]["Insert"]
        >;
      };
      pages: {
        Row: {
          id: string;
          org_id: string;
          workspace_id: string;
          parent_id: string | null;
          title: string;
          icon: string | null;
          content_text: string;
          is_archived: boolean;
          position: number;
          created_by: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          org_id: string;
          workspace_id: string;
          parent_id?: string | null;
          title?: string;
          icon?: string | null;
          content_text?: string;
          is_archived?: boolean;
          position?: number;
          created_by: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["pages"]["Insert"]>;
      };
      page_yjs_state: {
        Row: {
          page_id: string;
          org_id: string;
          workspace_id: string;
          state: string; // bytea returned as base64 / hex string from PostgREST
          updated_at: string;
        };
        Insert: {
          page_id: string;
          org_id: string;
          workspace_id: string;
          state: string;
          updated_at?: string;
        };
        Update: Partial<
          Database["public"]["Tables"]["page_yjs_state"]["Insert"]
        >;
      };
      invites: {
        Row: {
          id: string;
          org_id: string;
          workspace_id: string | null;
          email: string;
          role: WorkspaceRole;
          token: string;
          status: InviteStatus;
          invited_by: string;
          expires_at: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          org_id: string;
          workspace_id?: string | null;
          email: string;
          role?: WorkspaceRole;
          token: string;
          status?: InviteStatus;
          invited_by: string;
          expires_at?: string;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["invites"]["Insert"]>;
      };
      analytics_events: {
        Row: {
          id: number;
          org_id: string;
          workspace_id: string | null;
          page_id: string | null;
          user_id: string | null;
          event_type: AnalyticsEventType;
          metadata: Json;
          created_at: string;
        };
        Insert: {
          id?: number;
          org_id: string;
          workspace_id?: string | null;
          page_id?: string | null;
          user_id?: string | null;
          event_type: AnalyticsEventType;
          metadata?: Json;
          created_at?: string;
        };
        Update: Partial<
          Database["public"]["Tables"]["analytics_events"]["Insert"]
        >;
      };
    };
    Views: {
      v_top_contributors_30d: {
        Row: {
          org_id: string;
          workspace_id: string;
          user_id: string;
          display_name: string | null;
          email: string;
          pages_created: number;
          pages_updated: number;
          total_events: number;
        };
      };
    };
    Functions: {
      search_pages: {
        Args: {
          p_query: string;
          p_workspace_id?: string | null;
          p_limit?: number;
        };
        Returns: Array<{
          id: string;
          workspace_id: string;
          title: string;
          snippet: string;
          rank: number;
          updated_at: string;
        }>;
      };
      refresh_reporting_aggregates: {
        Args: Record<string, never>;
        Returns: void;
      };
      is_org_member: {
        Args: { p_org_id: string; p_user_id?: string };
        Returns: boolean;
      };
      is_org_admin: {
        Args: { p_org_id: string; p_user_id?: string };
        Returns: boolean;
      };
      is_workspace_member: {
        Args: { p_workspace_id: string; p_user_id?: string };
        Returns: boolean;
      };
      is_workspace_admin: {
        Args: { p_workspace_id: string; p_user_id?: string };
        Returns: boolean;
      };
    };
    Enums: {
      org_role: OrgRole;
      workspace_role: WorkspaceRole;
      invite_status: InviteStatus;
      analytics_event_type: AnalyticsEventType;
    };
  };
}
