/**
 * Next.js calls register() once per server process before any requests.
 * This is the hook for tracer + Sentry init.
 *
 * Important: this file MUST stay tiny and synchronous for the part that
 * matters. dd-trace must initialize before any other module imports, so
 * we require it via a side-effect module rather than importing async.
 */

export async function register() {
  // Tracer first. The `await import` is dynamic so the tracer's
  // monkey-patching can run before downstream imports resolve.
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { initTracer } = await import("@/lib/observability/tracer");
    initTracer();

    const { initSentry } = await import("@/lib/observability/sentry-server");
    initSentry();
  }
}

/**
 * Sentry's Next.js SDK hooks this to capture nested React Server Component
 * errors and Server Action errors. Re-export their helper.
 */
export { onRequestError } from "@sentry/nextjs";
