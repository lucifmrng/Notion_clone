import * as Sentry from "@sentry/nextjs";

/**
 * Edge runtime config. Next.js middleware runs on the edge runtime, which
 * is a stripped-down V8 environment without Node APIs. dd-trace doesn't
 * work here, but Sentry has an edge-compatible build.
 */
Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.SENTRY_ENV ?? process.env.NODE_ENV ?? "development",
  release: process.env.SENTRY_RELEASE,

  tracesSampleRate: 0,
  sendDefaultPii: false,
});
