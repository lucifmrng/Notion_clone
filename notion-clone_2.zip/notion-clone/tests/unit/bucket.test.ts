import { describe, it, expect } from "vitest";
import { bucketDailyActivity } from "@/features/reporting/bucket";

describe("bucketDailyActivity", () => {
  const since = new Date("2025-04-25T00:00:00Z");
  const until = new Date("2025-04-28T00:00:00Z");

  it("returns one row per day in the inclusive range", () => {
    const out = bucketDailyActivity([], since, until);
    expect(out.map((r) => r.day)).toEqual([
      "2025-04-25",
      "2025-04-26",
      "2025-04-27",
      "2025-04-28",
    ]);
    expect(out.every((r) => r.pages_created === 0 && r.pages_updated === 0)).toBe(true);
  });

  it("counts created and updated events separately", () => {
    const events = [
      { created_at: "2025-04-26T10:00:00Z", event_type: "page.created" },
      { created_at: "2025-04-26T11:00:00Z", event_type: "page.created" },
      { created_at: "2025-04-26T12:00:00Z", event_type: "page.updated" },
      { created_at: "2025-04-27T09:00:00Z", event_type: "page.updated" },
    ];
    const out = bucketDailyActivity(events, since, until);
    const apr26 = out.find((r) => r.day === "2025-04-26")!;
    const apr27 = out.find((r) => r.day === "2025-04-27")!;
    expect(apr26).toEqual({ day: "2025-04-26", pages_created: 2, pages_updated: 1 });
    expect(apr27).toEqual({ day: "2025-04-27", pages_created: 0, pages_updated: 1 });
  });

  it("ignores event types other than created/updated", () => {
    const events = [
      { created_at: "2025-04-26T10:00:00Z", event_type: "page.viewed" },
      { created_at: "2025-04-26T10:00:00Z", event_type: "page.deleted" },
    ];
    const out = bucketDailyActivity(events, since, until);
    expect(out.find((r) => r.day === "2025-04-26")).toEqual({
      day: "2025-04-26",
      pages_created: 0,
      pages_updated: 0,
    });
  });

  it("groups in UTC, not local time", () => {
    // 23:30 UTC on the 26th — must not roll into the 27th regardless of the
    // host machine's timezone.
    const events = [
      { created_at: "2025-04-26T23:30:00Z", event_type: "page.created" },
    ];
    const out = bucketDailyActivity(events, since, until);
    expect(out.find((r) => r.day === "2025-04-26")!.pages_created).toBe(1);
    expect(out.find((r) => r.day === "2025-04-27")!.pages_created).toBe(0);
  });

  it("survives malformed timestamps without throwing", () => {
    const events = [
      // @ts-expect-error
      { created_at: null, event_type: "page.created" },
      { created_at: "", event_type: "page.created" },
      { created_at: "2025-04-26T10:00:00Z", event_type: "page.created" },
    ];
    const out = bucketDailyActivity(events, since, until);
    expect(out.find((r) => r.day === "2025-04-26")!.pages_created).toBe(1);
  });
});
