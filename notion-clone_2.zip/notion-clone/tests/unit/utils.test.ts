import { describe, it, expect } from "vitest";
import { slugify, fractionalPosition } from "@/lib/utils";

describe("slugify", () => {
  it("lowercases and replaces spaces with hyphens", () => {
    expect(slugify("Hello World")).toBe("hello-world");
  });

  it("strips special characters", () => {
    expect(slugify("Q4 / 2025 — Goals!")).toBe("q4-2025-goals");
  });

  it("collapses repeated separators", () => {
    expect(slugify("a   b___c")).toBe("a-b-c");
  });

  it("trims leading and trailing hyphens", () => {
    expect(slugify("---hi---")).toBe("hi");
  });

  it("falls back to 'untitled' on empty / pure-symbol input", () => {
    expect(slugify("")).toBe("untitled");
    expect(slugify("!!!")).toBe("untitled");
    expect(slugify("   ")).toBe("untitled");
  });

  it("caps length at 48 characters", () => {
    const long = "a".repeat(100);
    expect(slugify(long).length).toBeLessThanOrEqual(48);
  });
});

describe("fractionalPosition", () => {
  it("returns 1024 when the list is empty", () => {
    expect(fractionalPosition(null, null)).toBe(1024);
  });

  it("appends after the last sibling", () => {
    expect(fractionalPosition(2048, null)).toBe(2048 + 1024);
  });

  it("prepends before the first sibling", () => {
    expect(fractionalPosition(null, 2048)).toBe(1024);
  });

  it("returns the midpoint between two siblings", () => {
    expect(fractionalPosition(100, 200)).toBe(150);
  });

  it("supports tight inserts without collision", () => {
    // Repeated midpoint inserts should keep producing distinct values.
    let a = 0;
    let b = 1024;
    const seen = new Set<number>([a, b]);
    for (let i = 0; i < 30; i++) {
      const mid = fractionalPosition(a, b);
      expect(seen.has(mid)).toBe(false);
      seen.add(mid);
      b = mid; // keep tightening on the left side
    }
  });
});
