import { describe, it, expect } from "vitest";
import { parseDocumentName } from "../../hocuspocus/src/document-name";

const UUID_A = "11111111-1111-4111-8111-111111111111";
const UUID_B = "22222222-2222-4222-8222-222222222222";

describe("parseDocumentName", () => {
  it("accepts the expected format", () => {
    expect(parseDocumentName(`${UUID_A}:${UUID_B}`)).toEqual({
      workspaceId: UUID_A,
      pageId: UUID_B,
    });
  });

  it("rejects empty and malformed strings", () => {
    expect(parseDocumentName("")).toBeNull();
    expect(parseDocumentName("notauuid")).toBeNull();
    expect(parseDocumentName(":")).toBeNull();
    expect(parseDocumentName(`${UUID_A}`)).toBeNull();
  });

  it("rejects when either side is not a UUID", () => {
    expect(parseDocumentName(`${UUID_A}:nope`)).toBeNull();
    expect(parseDocumentName(`nope:${UUID_B}`)).toBeNull();
    expect(parseDocumentName(`${UUID_A}:`)).toBeNull();
    expect(parseDocumentName(`:${UUID_B}`)).toBeNull();
  });

  it("rejects extra colons (no embedded delimiters)", () => {
    expect(parseDocumentName(`${UUID_A}:${UUID_B}:extra`)).toBeNull();
  });

  it("rejects non-string input", () => {
    // @ts-expect-error — runtime guard against type-coerced inputs
    expect(parseDocumentName(null)).toBeNull();
    // @ts-expect-error
    expect(parseDocumentName(undefined)).toBeNull();
    // @ts-expect-error
    expect(parseDocumentName({ workspaceId: UUID_A, pageId: UUID_B })).toBeNull();
  });

  it("rejects look-alikes that aren't UUIDs", () => {
    // 31 hex chars instead of 32 in the last group
    expect(parseDocumentName(`${UUID_A}:11111111-1111-4111-8111-11111111111`)).toBeNull();
    // Wrong separator placement
    expect(parseDocumentName(`${UUID_A}:1111111111114111811111111111111`)).toBeNull();
  });
});
