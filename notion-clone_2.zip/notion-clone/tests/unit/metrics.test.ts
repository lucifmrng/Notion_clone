import { describe, it, expect } from "vitest";
import { metrics, timed } from "@/lib/observability/metrics";

describe("metrics facade", () => {
  it("does not throw when dd-trace is unavailable", () => {
    // dd-trace isn't initialized in unit tests, so the facade should resolve
    // to no-ops. Calling any method must not throw.
    expect(() => metrics.increment("notion.test.counter")).not.toThrow();
    expect(() => metrics.gauge("notion.test.gauge", 42)).not.toThrow();
    expect(() => metrics.histogram("notion.test.hist", 100, ["a:b"])).not.toThrow();
    expect(() => metrics.distribution("notion.test.dist", 1)).not.toThrow();
    expect(() => metrics.timing("notion.test.timing", 50)).not.toThrow();
  });

  it("returns the function value from timed()", async () => {
    const result = await timed("notion.test.timed", [], async () => 42);
    expect(result).toBe(42);
  });

  it("propagates errors from the wrapped function", async () => {
    await expect(
      timed("notion.test.timed_err", [], async () => {
        throw new Error("boom");
      }),
    ).rejects.toThrow("boom");
  });

  it("times correctly even on errors", async () => {
    // The facade is no-op in tests; this just verifies no extra failure mode.
    const start = Date.now();
    try {
      await timed("notion.test.timed_slow", [], async () => {
        await new Promise((r) => setTimeout(r, 10));
        throw new Error("after delay");
      });
    } catch {
      // expected
    }
    expect(Date.now() - start).toBeGreaterThanOrEqual(10);
  });
});
